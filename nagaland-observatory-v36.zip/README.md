# Nagaland Education Observatory

Where Nagaland's students stop, and where to help first.

A single self-contained web page (fonts, images, charts and data are all inside `index.html`). Open `index.html` in any browser, or publish with GitHub Pages.

Version 36. Sources are listed inside the page under each chart ("Details and source").
