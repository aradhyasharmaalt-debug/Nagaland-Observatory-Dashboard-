import os
HERE=os.path.dirname(os.path.abspath(__file__))
os.chdir(HERE)
css=open('style.css').read();body=open('body.html').read()
js=''.join(open(f).read()+'\n' for f in ['data.js','lib.js','art.js','plate.js','mapdata.js','charts.js','charts2.js','charts3.js','main.js'])
head='''<title>Nagaland Education Observatory v36</title>
<meta name="claude:viewport-fit-sides" content="cover">
<meta name="description" content="Where Nagaland's students stop, and where to help first. A free-scroll story in three parts: see, act, fill the gaps.">
'''
import base64
F=os.environ.get('FONTS_DIR','node_modules')+'/@fontsource/'
def ff(fam,pkg,file,wt,st='normal'):
    b=base64.b64encode(open(F+pkg+'/files/'+file,'rb').read()).decode()
    return "@font-face{font-family:'%s';font-weight:%s;font-style:%s;font-display:swap;src:url(data:font/woff2;base64,%s) format('woff2')}\n"%(fam,wt,st,b)
fonts=ff('Anton','anton','anton-latin-400-normal.woff2',400)+ff('Fraunces','fraunces','fraunces-latin-500-italic.woff2',500,'italic')+''.join(ff('Figtree','figtree','figtree-latin-%d-normal.woff2'%w,w) for w in (500,700,800))
css=fonts+css
open('../index.html','w').write('<meta charset="utf-8">\n'+head+'<style>\n'+css+'\n</style>\n'+body+'\n<script>\n'+js+'\n</script>\n')
print('built')
