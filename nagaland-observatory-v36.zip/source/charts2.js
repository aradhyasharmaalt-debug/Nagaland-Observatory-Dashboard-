/* ---- additions: story gaps ---- */
const INK2='#16110F';
/* narrowing flags */
(function(){const n=D.ner['2025–26'],t=D.tr['2025–26'];
 $('#flag2').innerHTML=`<i>1</i><div><b>First narrowing · upper primary</b><span>Right-age enrolment falls from ${f1(D.ner['2024–25'].ng[0])} in 100 at primary to ${f1(D.ner['2024–25'].ng[1])} at upper primary (2024–25).</span></div>`;
 $('#flag4').innerHTML=`<i>2</i><div><b>Second narrowing · Class 10 to 11</b><span>${f1(t.Nagaland[2])} in 100 continue, the lowest of the three steps.</span></div>`})();

/* 02 'right age?' view: all ages vs right age, same year */
function ageView(w){
 const g=D.ger['2024–25'],n=D.ner['2024–25'].ng,R=w<520?104:176,Rt=14,rh=62,top=8,H=top+rh*4+26,X=v=>R+(w-R-Rt)*v/100;
 const vi=g.ng.map((v,i)=>+(v-n[i]).toFixed(1)),mi=vi.indexOf(Math.max(...vi));
 $('#cap2').textContent=`At upper primary, ${f1(g.ng[1])} in 100 are enrolled but only ${f1(n[1])} are the right age.`;
 $('#src2').textContent='UDISE+ 2024–25. All-ages enrolment as reported by The Morung Express, 7 September 2025. Right-age enrolment is the 2024–25 figure used elsewhere on this page. The two measures differ when students are older or younger than the official age, which fits late entry or repeating, and population estimates also play a part. The records here do not show which applies.';
 let s=`<svg viewBox="0 0 ${w} ${H}" width="${w}" height="${H}" style="max-width:100%;height:auto" role="img" aria-label="All-ages and right-age enrolment by stage, 2024–25"><defs><pattern id="gapH" width="9" height="9" patternUnits="userSpaceOnUse" patternTransform="rotate(45)"><rect width="9" height="9" fill="rgba(245,235,216,.08)"/><line x1="0" y1="0" x2="0" y2="9" stroke="#F5EBD8" stroke-width="3" opacity=".6"/></pattern></defs>`;
 [0,25,50,75,100].forEach(t=>s+=`<line x1="${X(t)}" x2="${X(t)}" y1="${top}" y2="${H-24}" class="s-soft" stroke-width="1" stroke-dasharray="2 6"/><text x="${X(t)}" y="${H-6}" text-anchor="middle" class="lab" style="font-size:12px;opacity:.85">${t}</text>`);
 g.ng.forEach((v,i)=>{const y=top+rh*i+10,bh=30,hot=i===mi;
  s+=`<g ${tp(D.stages[i].name,'All ages: '+f1(v)+'%. Right age: '+f1(n[i])+'%.')} tabindex="0"><text x="0" y="${y+bh/2+5}" style="font:800 ${w<520?12:14}px var(--body);letter-spacing:.06em;text-transform:uppercase;fill:var(--fg)">${w<520?['Primary','Upper pri.','Secondary','Higher sec.'][i]:D.stages[i].name}</text>
  <rect x="${X(n[i])}" y="${y}" width="${X(v)-X(n[i])}" height="${bh}" fill="url(#gapH)" stroke="#F5EBD8" stroke-width="2"/><rect x="${X(0)}" y="${y}" width="${X(n[i])-X(0)}" height="${bh}" style="fill:${hot?'var(--bad)':STGC[i]}" stroke="${INK2}" stroke-width="2"/></g>`});
 const key=g.ng.map((v,i)=>`<div class="nk ${i===mi?'hot':''}" ${tp(D.stages[i].name,'All ages '+f1(v)+'%. Right age '+f1(n[i])+'%.')}><i style="background:${i===mi?'#16110F':STGC[i]}"></i><b>${D.stages[i].name}</b><span class="big">${f1(n[i])}%</span><span class="in">right age · all ages ${f1(v)}%</span><em>${f1(Math.abs(v-n[i]))} pts apart</em></div>`).join('');
 return `<div class="plate-wrap" style="display:block">${s}</svg></div><div class="nkeys">${key}</div><p class="nhint"><span><i style="background:#F5EBD8"></i>Solid: right age</span><span><i style="background:repeating-linear-gradient(45deg,#F5EBD8 0 3px,transparent 3px 7px)"></i>Hatched: other ages</span></p>`}

/* 03 real map: colour = net enrolment, circle area = government schools */
ST.m3=3;
mount('v3b',w=>{const si=ST.m3,sn=D.stages[si].name,vals=D.dist.map(d=>d.ner[si]),mn=Math.min(...vals),mx=Math.max(...vals),gm=Math.max(...D.dist.map(d=>d.gov[si]));
 const lab=w>=700,M=lab?170:0,Wd=NGM.W+2*M,Hh=NGM.H,c0=[240,224,190],c1=[150,16,32],
  col=v=>{const t=Math.pow((v-mn)/((mx-mn)||1),.85);return 'rgb('+c0.map((a,i)=>Math.round(a+(c1[i]-a)*t)).join(',')+')'},
  rad=g=>8+28*Math.sqrt(g/gm);
 let s=`<svg viewBox="0 0 ${Wd} ${Hh}" style="width:${Math.min(w,Wd)}px;max-width:100%;height:auto;display:block;margin:0 auto" role="img" aria-label="Map of Nagaland's 11 districts. Colour shows ${sn.toLowerCase()} net enrolment, circle size shows government schools">`;
 s+=`<g transform="translate(${M} 0)">`;
 D.dist.forEach(d=>{const v=d.ner[si];s+=`<path d="${NGM.p[d.name]}" fill="${col(v)}" stroke="#16110F" stroke-width="2.2" stroke-linejoin="round" ${tp(d.name,sn+' net enrolment '+f1(v)+'%'+(v>100?' (above 100%: counts students outside the official age band)':'')+' · '+d.gov[si]+' government schools')} tabindex="0"/>`});
 const L=[],R=[];
 D.dist.forEach(d=>{const [x,y]=NGM.c[d.name],g=d.gov[si],r=rad(g);
  s+=`<g style="pointer-events:none"><circle cx="${x}" cy="${y}" r="${r.toFixed(1)}" fill="#16110F" fill-opacity=".86" stroke="#F5EBD8" stroke-width="2"/><text x="${x}" y="${y+5}" text-anchor="middle" style="font:800 ${r>14?14:12}px var(--body);fill:#F5EBD8">${g}</text></g>`;
  (x<300?L:R).push({d,x,y,r})});
 if(lab){[[L,0],[R,1]].forEach(([arr,right])=>{arr.sort((a,b)=>a.y-b.y);let py=-99;arr.forEach(o=>{o.ly=Math.max(o.y,py+34);py=o.ly});
  const over=arr.length&&arr[arr.length-1].ly-(Hh-20);if(over>0)arr.forEach(o=>o.ly-=over);
  arr.forEach(o=>{const lx=right?NGM.W+22:-22,ax=right?'start':'end';
   s+=`<polyline points="${o.x},${o.y} ${right?NGM.W+10:-10},${o.ly} ${lx-(right?6:-6)},${o.ly}" fill="none" stroke="#16110F" stroke-width="1.5" opacity=".55"/><text x="${lx}" y="${o.ly-2}" text-anchor="${ax}" style="font:800 15px var(--body);fill:#16110F">${o.d.name}</text><text x="${lx}" y="${o.ly+15}" text-anchor="${ax}" style="font:600 13px var(--body);fill:#16110F;opacity:.8">${f1(o.d.ner[si])}%</text>`})})}
 s+='</g></svg>';
 const rank=D.dist.slice().sort((a,b)=>b.ner[si]-a.ner[si]);
 const key=`<div class="mkeys">${rank.map(d=>`<div class="mk" ${tp(d.name,sn+' net enrolment '+f1(d.ner[si])+'%. '+d.gov[si]+' government schools.')}><i style="background:${col(d.ner[si])}"></i><b>${d.name}</b><span>${f1(d.ner[si])}%</span><small>${d.gov[si]} ${d.gov[si]===1?'school':'schools'}</small></div>`).join('')}</div>`;
 const leg=`<div class="mleg"><div><div class="ramp" style="--ramp0:rgb(${c0});--ramp1:rgb(${c1})"></div><div class="rampl"><span>${f1(mn)}%</span><span>DARKER = MORE ENROLLED</span><span>${f1(mx)}%</span></div></div><div class="msz"><svg viewBox="0 0 120 80" aria-hidden="true"><circle cx="22" cy="58" r="${rad(Math.max(1,Math.round(gm/6))).toFixed(1)}" fill="#16110F"/><circle cx="76" cy="42" r="${rad(gm).toFixed(1)}" fill="#16110F"/></svg><span>Circle area = government ${sn.toLowerCase()} schools (${Math.max(1,Math.round(gm/6))} to ${gm})</span></div></div>`;
 return s+leg+key});
pills('pills3b',D.stages.map((s,i)=>({v:String(i),t:s.name})),String(ST.m3),v=>{ST.m3=+v;redraw('v3b');capMap()});
function capMap(){const si=ST.m3,sn=D.stages[si].name.toLowerCase(),r=D.dist.slice().sort((a,b)=>b.ner[si]-a.ner[si]),hi=r[0],lo=r[r.length-1];
 $('#cap3b').textContent=`${f1(lo.ner[si])}% in ${lo.name} to ${f1(hi.ner[si])}% in ${hi.name} at ${sn} level. The records do not say why.`}
capMap();

/* 04 PARAKH */
(function(){const P=D.parakh,mx=Math.max(...P.map(p=>p[1]));
 $('#v4d').innerHTML=`<div class="ladder lt">${P.map((p,i)=>`<div class="rung" ${tp(p[0],p[1]+'% of reporting schools (school-reported estimate).')} tabindex="0"><span class="nm" style="text-transform:none;letter-spacing:0;font-size:15px;line-height:1.25">${p[0].replace('More than half of students ','Most students ').replace('More than half ','Most ')}</span><span class="bar"><i style="width:${p[1]/mx*100}%"></i></span><span class="ct">${p[1]}%</span></div>`).join('')}</div>`})();

/* 05 teachers */
(function(){const p=D.ptr,N=Math.round(p.ng),M=Number(p.prevSingle)||31;
 const kid=i=>`<svg class="kid" style="--i:${i}" viewBox="0 0 20 30" width="28" height="42" aria-hidden="true"><circle cx="10" cy="7" r="5.5"/><path d="M2 30V22a8 8 0 0 1 16 0v8z"/></svg>`;
 const tch=`<svg class="tch" viewBox="0 0 40 62" width="72" height="112" aria-hidden="true"><path d="M3 20 20 12l17 8-17 8z" class="cap"/><circle cx="20" cy="37" r="8"/><path d="M4 62v-6a16 10 0 0 1 32 0v6z"/></svg>`;
 const sch=i=>`<svg class="ghost" style="--i:${i}" viewBox="0 0 24 24" width="30" height="30" aria-hidden="true"><path d="M3 11 12 3l9 8v10H3z"/><circle cx="12" cy="14" r="2.4" class="pp"/></svg>`;
 $('#ptr').innerHTML=`<h3 class="mini-h" style="margin-top:0">One thing the numbers do not flag <small class="vint">UDISE+ 2024–25</small></h3>
 <div class="ptr-row anim" id="ptrv">
  <div class="pc" ${tp('Students per teacher',N+' students for each teacher in Nagaland, UDISE+ 2024–25. This counts teachers, not subject coverage.')} tabindex="0"><p class="pt-h">Each teacher has about ${N} students</p>
   <div class="fig"><div class="kids" role="img" aria-label="${N} students">${Array.from({length:N},(_,i)=>kid(i)).join('')}</div><span class="arr" aria-hidden="true">→</span><div class="one">${tch}<b>1 teacher</b></div></div>
   <p class="pt-n"><span class="n">${N}</span> students per teacher. <em>India: about ${p.ind}.</em></p></div>
  <div class="pc" ${tp('Single-teacher schools','29 in 2021–22, 35 in 2022–23, 31 in 2023–24, 0 in 2024–25.')} tabindex="0"><p class="pt-h">Schools run by a single teacher</p>
   <div class="sbar">${(()=>{const S=[['2021–22',29],['2022–23',35],['2023–24',31],['2024–25',p.single]],bw=58,gp=30,x0=14,base=176,K=140/40;let s=`<svg viewBox="0 0 ${x0*2+4*bw+3*gp} 214" width="100%" role="img" aria-label="Single-teacher schools in Nagaland: ${S.map(a=>a[0]+', '+a[1]).join('; ')}" style="max-width:420px;display:block">`;
    [0,10,20,30,40].forEach(t=>{s+=`<line x1="0" x2="${x0*2+4*bw+3*gp}" y1="${base-t*K}" y2="${base-t*K}" stroke="currentColor" stroke-opacity="${t?0.15:0.6}" stroke-width="${t?1:2}"/>`});
    S.forEach((a,k)=>{const x=x0+k*(bw+gp),h=a[1]*K,last=k===3,col=last?'#1D5A41':'#16110F';
     s+=`<rect x="${x}" y="${base-h}" width="${bw}" height="${Math.max(h,0)}" rx="4" fill="${col}" class="sb" style="--d:${k*120}ms"/>`;
     s+=`<text x="${x+bw/2}" y="${base-h-8}" text-anchor="middle" style="font:400 ${last?34:26}px var(--disp);fill:${col}">${a[1]}</text>`;
     s+=`<text x="${x+bw/2}" y="${base+22}" text-anchor="middle" style="font:800 12px var(--body);fill:currentColor">${a[0]}</text>`});
    return s+`<text x="${x0+3*(bw+gp)+bw/2}" y="${base-52}" text-anchor="middle" style="font:800 11px var(--body);fill:#1D5A41;letter-spacing:.08em">NONE LEFT</text></svg>`})()}</div>
   <p class="pt-n">From 29 schools in 2021–22 to ${p.single} in 2024–25. <em>A one-teacher school has a single teacher for every class. Sources: Ministry of Education (2021–22); UDISE+ via Morung Express (2022–25).</em></p></div>
 </div><p class="cap" style="margin-top:12px">Staffing looks comfortable on paper. This counts teachers, not how well subjects are covered at higher secondary.</p>`})();

/* 06 higher-education */
mount('v6d',w=>{const a=D.he.ger,H=240,L=44,Rr=100,T=34,B=40,X=i=>L+(w-L-Rr)*i/(a.length-1),Y=v=>T+(H-T-B)*(1-(v-16)/(22-16));
 let s=`<svg viewBox="0 0 ${w} ${H}" width="${w}" height="${H}" style="max-width:100%;height:auto" role="img" aria-label="Higher education gross enrolment ratio, ages 18 to 23, 2020–21 to 2024–25">`;
 [16,18,20,22].forEach(t=>s+=`<line x1="${L}" x2="${w-Rr+10}" y1="${Y(t)}" y2="${Y(t)}" class="s-soft" stroke-width="1" stroke-dasharray="2 6"/><text x="${L-10}" y="${Y(t)+4}" text-anchor="end" class="lab" style="font-size:12px">${t}</text>`);
 s+=`<polyline fill="none" stroke="var(--good)" stroke-width="5" stroke-linejoin="round" stroke-linecap="round" points="${a.map((p,i)=>X(i)+','+Y(p[1])).join(' ')}"/>`;
 a.forEach((p,i)=>{const last=i===a.length-1;s+=`<g ${tp(p[0],'Gross enrolment ratio, ages 18–23: '+p[1]+'.')} tabindex="0"><circle cx="${X(i)}" cy="${Y(p[1])}" r="${last?10:7}" style="fill:${last?'var(--good)':'#F5EBD8'}" stroke="${INK2}" stroke-width="3"/><text x="${X(i)}" y="${H-14}" text-anchor="middle" class="lab" style="font-size:${w<460?10:12}px">${w<460?p[0].slice(2,4)+'–'+p[0].slice(5):p[0]}</text>${last?`<text x="${X(i)+16}" y="${Y(p[1])+8}" style="font:400 34px var(--disp)">${p[1]}</text>`:''}</g>`});
 return s+`</svg>`});
(function(){const h=D.he;$('#cap6d').textContent=`Women ${h.f}, men ${h.m} per 100 aged 18–23. ${nf(h.enrol)} students enrolled in 2024–25.`})();

/* 08 putting it together: three drops inside Nagaland, one blank */
mount('v8',w=>{const n=D.ner['2025–26'],t=D.tr['2025–26'].Nagaland,RED='#C4162C',
 rows=[{h:'Upper primary',s:'right-age enrolment',a:n.ng[1],b:n.ng[0],bl:'Primary'},{h:'Class 10 → 11',s:'continue',a:t[2],b:t[1],bl:'Class 8 → 9'},{h:'Higher secondary',s:'right-age enrolment',a:n.ng[3],b:n.ng[2],bl:'Secondary'},{h:'After Class 12',s:'',a:null}],
 L=14,Rr=24,rh=130,top=34,H=top+rh*4+30,X=v=>L+(w-L-Rr)*v/100;
 let s=`<svg viewBox="0 0 ${w} ${H}" width="${w}" height="${H}" style="max-width:100%;height:auto" role="img" aria-label="Three places where the numbers narrow in Nagaland, and a blank for after Class 12"><defs><pattern id="unk" width="10" height="10" patternUnits="userSpaceOnUse" patternTransform="rotate(45)"><line x1="0" y1="0" x2="0" y2="10" stroke="#16110F" stroke-width="2" opacity=".35"/></pattern></defs>`;
 s+=`<g><circle cx="${L+9}" cy="14" r="9" fill="${RED}"/><text x="${L+26}" y="19" style="font:800 14px var(--body);fill:#16110F">This step</text><circle cx="${L+130}" cy="14" r="8" fill="#F6EBDC" stroke="#16110F" stroke-width="3"/><text x="${L+146}" y="19" style="font:800 14px var(--body);fill:#16110F">The step before</text></g>`;
 rows.forEach((r,i)=>{const y=top+rh*i,cy=y+88;
  s+=`<text x="${L}" y="${y+22}" style="font:800 15px var(--body);letter-spacing:.1em;text-transform:uppercase;fill:#16110F">${r.h}${r.s?`<tspan style="font-weight:600;letter-spacing:0;text-transform:none;opacity:.75"> · ${r.s}</tspan>`:''}</text>`;
  s+=`<line x1="${X(0)}" x2="${X(100)}" y1="${cy}" y2="${cy}" stroke="#16110F" stroke-width="3" opacity=".18" stroke-linecap="round"/>`;
  if(r.a==null){s+=`<g ${tp('After Class 12','Not tracked in the public records reviewed.')} tabindex="0"><rect x="${X(0)}" y="${cy-18}" width="${X(100)-X(0)}" height="36" rx="18" fill="url(#unk)" stroke="#16110F" stroke-width="2.5" stroke-dasharray="8 6"/><circle cx="${w/2}" cy="${cy}" r="20" fill="#F6EBDC" stroke="#16110F" stroke-width="3" stroke-dasharray="3 4"/><text x="${w/2}" y="${cy+9}" text-anchor="middle" style="font:400 28px var(--disp);fill:#16110F">?</text></g>`;return}
  const gap=+(r.b-r.a).toFixed(1);
  s+=`<g ${tp(r.h,f1(r.a)+'%. The step before ('+r.bl+'): '+f1(r.b)+'%. Fall of '+f1(Math.abs(gap))+' percentage points.')} tabindex="0"><line x1="${X(Math.min(r.a,r.b))}" x2="${X(Math.max(r.a,r.b))}" y1="${cy}" y2="${cy}" stroke="${RED}" stroke-width="12" stroke-linecap="round"/><circle cx="${X(r.b)}" cy="${cy}" r="12" fill="#F6EBDC" stroke="#16110F" stroke-width="3.5"/><circle cx="${X(r.a)}" cy="${cy}" r="17" fill="${RED}" stroke="#16110F" stroke-width="3.5"/>
  <text x="${X(r.a)}" y="${cy-26}" text-anchor="middle" style="font:400 38px var(--disp);fill:${RED}">${f1(r.a)}</text><text x="${X(r.b)}" y="${cy+40}" text-anchor="middle" style="font:400 24px var(--disp);fill:#16110F">${f1(r.b)}</text></g>`});
 [0,50,100].forEach(v=>s+=`<text x="${X(v)}" y="${H-6}" text-anchor="${v===0?'start':v===100?'end':'middle'}" class="lab" style="font-size:12px">${v}%</text>`);
 return s+'</svg>'});
(function(){const A=D.acc[3],sch=D.dist.reduce((a,d)=>a+d.gov[3],0),pr=D.dist.reduce((a,d)=>a+d.gov[0],0);
 const tiles=[{n:Math.round(A.pc)+'%',l:'villages lack higher-secondary access · March 2025',ic:'<path d="M6 30 L30 10 L54 30 V54 H6Z" fill="none" stroke="currentColor" stroke-width="4" stroke-linejoin="round"/><path d="M6 54 V42 H54 V54Z" fill="#C4162C"/>'},{n:String(sch),l:'government higher-secondary schools, against '+nf(pr)+' primary',ic:'<rect x="6" y="40" width="48" height="14" fill="currentColor"/><rect x="14" y="24" width="32" height="14" fill="currentColor" opacity=".6"/><rect x="22" y="8" width="16" height="14" fill="#C4162C"/>'},{n:'31%',l:'of surveyed leavers named money · 2018 survey',ic:'<circle cx="30" cy="30" r="22" fill="none" stroke="currentColor" stroke-width="4"/><circle cx="30" cy="30" r="12" fill="#C4162C"/>'}];
 const nx=[['1','Funders','Pay for a cohort follow-up and a count of who leaves after Class 10 and 12.'],['2','Government','Publish the distance cut-off for "too far" and split key figures by district.'],['3','Researchers','Test whether distance and money explain the drop, which these records do not show.']];
 $('#v8b').innerHTML=`<p class="alo-h">Alongside the gaps <small>not shown to be causes</small></p><div class="alo">${tiles.map(t=>`<div class="at"><svg viewBox="0 0 60 60" aria-hidden="true">${t.ic}</svg><b>${t.n}</b><span>${t.l}</span></div>`).join('')}</div><p class="alo-h" style="margin-top:34px">Who can fill the gaps</p><div class="nxs">${nx.map(x=>`<div><i>${x[0]}</i><b>${x[1]}</b>${x[2]}</div>`).join('')}</div>`})();

/* 01 most literate states: Nagaland placed at its own figure */
mount('lit',w=>{const rows=D.lit.top.concat([D.lit.ng]),mn=70,mx=100,L=w<520?96:150,Rr=58,rh=44,T=6,H=T+rh*rows.length+34+22,X=v=>L+(w-L-Rr)*(v-mn)/(mx-mn);
 let s=`<svg viewBox="0 0 ${w} ${H}" width="${w}" height="${H}" style="max-width:100%;height:auto" role="img" aria-label="Literacy rate, Census 2011: Kerala, Mizoram, Goa, Tripura and Himachal Pradesh, with Nagaland shown at its own figure. Axis starts at 70 percent">`;
 [70,80,90,100].forEach(t=>s+=`<line x1="${X(t)}" x2="${X(t)}" y1="${T}" y2="${H-30}" class="s-soft" stroke-width="1" stroke-dasharray="2 6"/><text x="${X(t)}" y="${H-10}" text-anchor="middle" class="lab" style="font-size:12px">${t}%</text>`);
 rows.forEach((r,i)=>{const gapRow=i===rows.length-1,y=T+rh*i+(gapRow?22:0),cy=y+rh/2,hot=r.hot;
  s+=`<g ${tp(r.n,'Literacy rate '+r.v.toFixed(r.hot?2:1)+'% (Census 2011, age 7+).')} tabindex="0"><text x="${L-12}" y="${cy+5}" text-anchor="end" style="font:${hot?800:700} ${w<520?13:15}px var(--body);fill:${hot?'var(--hi)':'var(--fg)'}">${r.n}</text><line x1="${X(mn)}" x2="${X(r.v)}" y1="${cy}" y2="${cy}" stroke="${hot?'var(--hi)':'var(--fg)'}" stroke-width="${hot?12:8}" stroke-linecap="round" opacity="${hot?1:.55}"/><circle cx="${X(r.v)}" cy="${cy}" r="${hot?15:10}" fill="${hot?'var(--hi)':'var(--bg)'}" stroke="var(--fg)" stroke-width="3"/><text x="${X(r.v)+(hot?24:18)}" y="${cy+7}" style="font:400 ${hot?30:22}px var(--disp);fill:${hot?'var(--hi)':'var(--fg)'}">${r.v.toFixed(hot?2:1)}</text></g>`;
  if(gapRow)s+=`<text x="${L-12}" y="${y-8}" text-anchor="end" style="font:700 13px var(--body);fill:var(--fg);opacity:.6">…</text>`});
 return s+'</svg>'});
