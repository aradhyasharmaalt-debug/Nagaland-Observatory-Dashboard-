const $=(s,r=document)=>r.querySelector(s),$$=(s,r=document)=>[...r.querySelectorAll(s)];
const nf=n=>n.toLocaleString('en-IN'),f1=v=>v.toFixed(1),f2=v=>v.toFixed(2);
const esc=s=>String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/"/g,'&quot;');
const tp=(t,d)=>`data-tip="${esc(t+'|'+(d||''))}"`;
const sgn=v=>v>0?'+':v<0?'−':'';
const REG={};
function mount(id,fn){const el=$('#'+id);if(!el)return;const o={el,fn,w:0};REG[id]=o;draw(o);new ResizeObserver(()=>{const w=Math.round(el.clientWidth);if(w&&Math.abs(w-o.w)>6)draw(o)}).observe(el)}
function draw(o){o.w=Math.round(o.el.clientWidth)||600;o.el.innerHTML=o.fn(o.w)}
const redraw=id=>REG[id]&&draw(REG[id]);
function bindSeg(id,cb){const el=$('#'+id);el.onclick=e=>{const b=e.target.closest('button');if(!b)return;$$('button',el).forEach(x=>x.setAttribute('aria-pressed',x===b));cb(b.dataset.v)}}
function pills(id,opts,cur,cb){const el=$('#'+id);el.innerHTML=opts.map(o=>`<button type="button" aria-pressed="${o.v===cur}" data-v="${esc(o.v)}">${o.t||o.v}</button>`).join('');bindSeg(id,cb)}
/* tooltip */
const tipEl=$('#tip');
function showTip(txt,x,y){const [t,d]=txt.split('|');tipEl.innerHTML=`<b>${t}</b>${d||''}`;tipEl.classList.add('on');const w=tipEl.offsetWidth,h=tipEl.offsetHeight;let lx=x+14,ly=y+16;if(lx+w>innerWidth-8)lx=x-w-14;if(ly+h>innerHeight-8)ly=y-h-14;tipEl.style.left=Math.max(8,lx)+'px';tipEl.style.top=Math.max(8,ly)+'px'}
document.addEventListener('pointermove',e=>{const t=e.target.closest&&e.target.closest('[data-tip]');if(t)showTip(t.dataset.tip,e.clientX,e.clientY);else tipEl.classList.remove('on')});
document.addEventListener('focusin',e=>{const t=e.target.closest&&e.target.closest('[data-tip]');if(t){const r=t.getBoundingClientRect();showTip(t.dataset.tip,r.left+r.width/2,r.bottom)}});
document.addEventListener('focusout',()=>tipEl.classList.remove('on'));
document.addEventListener('scroll',()=>tipEl.classList.remove('on'),{passive:true});
/* shared segment highlight */
function hl(e,on){const s=e.target.closest&&e.target.closest('[data-seg]');if(!s)return;const sc=s.closest('.wf');if(!sc)return;const k=s.dataset.seg;$$('[data-seg]',sc).forEach(x=>x.classList.toggle('dim',on&&x.dataset.seg!==k))}
['pointerover','focusin'].forEach(n=>document.addEventListener(n,e=>hl(e,true)));
['pointerout','focusout'].forEach(n=>document.addEventListener(n,e=>hl(e,false)));
/* unit grids */
function alloc(vals,n){const t=vals.reduce((a,b)=>a+b,0),raw=vals.map(v=>v/t*n),fl=raw.map(Math.floor);let rest=n-fl.reduce((a,b)=>a+b,0);raw.map((r,i)=>[r-fl[i],i]).sort((a,b)=>b[0]-a[0]).slice(0,rest).forEach(o=>fl[o[1]]++);return fl}
function waffle(items,o={}){const sym=o.sym||'p',cols=o.cols||10,n=o.n||100,cnt=alloc(items.map(i=>i.v),n);let idx=0,c='';
 items.forEach((it,si)=>{for(let k=0;k<cnt[si];k++,idx++){c+=`<use href="#${sym}" class="cell" data-seg="${it.k}" data-tip="${esc(it.tip||'')}" x="${(idx%cols)*11}" y="${Math.floor(idx/cols)*11}" width="10" height="10" style="fill:${it.col};animation-delay:${Math.min(idx*5,420)}ms"/>`}});
 return `<svg viewBox="0 0 ${cols*11-1} ${Math.ceil(n/cols)*11-1}" role="img" aria-label="${esc(o.label||'')}">${c}</svg>`}
function legend(items){return `<ul class="legend">${items.map(i=>`<li><button type="button" data-seg="${i.k}" data-tip="${esc(i.tip||'')}"><i style="background:${i.col}"></i><span>${i.t}${i.val?' <b>'+i.val+'</b>':''}</span></button></li>`).join('')}</ul>`}
