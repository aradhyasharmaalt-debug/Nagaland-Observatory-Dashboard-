const D={
stages:[{k:'p',name:'Primary',grades:'1st–5th'},{k:'u',name:'Upper primary',grades:'6th–8th'},{k:'s',name:'Secondary',grades:'9th–10th'},{k:'h',name:'Higher secondary',grades:'11th–12th'}],
enrol:{'2025–26':[162368,86040,53260,37009],'2024–25':[162251,86933,53972,36670]},
adm:[['2023–24',36171],['2024–25',37050],['2025–26',36012]],
ner:{'2025–26':{ng:[80.0,51.2,37.4,26.3],ind:[77.1,68.4,50.8,39.0]},'2024–25':{ng:[78.2,50.6,37.5,25.3],ind:[76.9,67.3,47.5,35.8]}},
tr:{'2025–26':{'Nagaland':[92.8,88.6,74.7],'Arunachal Pradesh':[91.3,87.4,71.5],'Mizoram':[98.9,91.4,67.6],'India':[93.8,88.3,78.1]},
    '2024–25':{'Nagaland':[91.5,83.8,75.3],'Arunachal Pradesh':[90.4,83.3,60.7],'Mizoram':[91.1,77.8,58.5],'India':[92.2,86.6,75.1]}},
trSteps:[['5th → 6th','Primary to upper primary'],['8th → 9th','Upper primary to secondary'],['10th → 11th','Secondary to higher secondary']],
drop:{'Nagaland':[12.1,13.3],'Arunachal Pradesh':[18.3,13.0],'Mizoram':[17.4,9.3],'India':[11.5,9.5]},
hslc:{years:[2021,2022,2023,2024,2025,2026],priv:[85.58,82.08,91.15,86.77,87.64,86.13],gov:[44.86,36.62,49.13,48.55,48.41,43.26]},
acc:[{name:'Primary',n:266,pc:12.88},{name:'Upper primary',n:601,pc:29.09},{name:'Secondary',n:247,pc:17.72},{name:'Higher secondary',n:744,pc:53.37}],
left:[['Middle school',61,'indigo'],['Secondary',31,'c4'],['Primary',8,'grey']],
why:[['Financial issues',31,'ochre'],['Family reasons',21,'indigo'],['Health',14,'c3'],['School-related',13,'c4'],['Other or unspecified',21,'grey']],
plan:[['Higher education',1957,'green'],['Get a job',261,'ochre'],['Apprenticeship or internship',147,'indigo'],['Other jobs',45,'c3'],['Gap year before college',38,'c4'],['Vocational training',5,'grey']],
guid:[['Enough to decide',33,'green'],['Reasonable, wanted more',34,'indigo'],['Little',29,'ochre'],['None',4,'grey']],
ug:[['Dimapur',18740],['Kohima',13527],['Mokokchung',1738],['Zunheboto',938],['Mon',832],['Tuensang',744],['Peren',650],['Phek',617],['Wokha',266],['Longleng',227],['Kiphire',218],['Chümoukedima',137],['Niuland',110]],
mv:[['Kohima',4142],['Dimapur',2314],['Mokokchung',1956],['Mon',1515],['Tuensang',1477],['Wokha',879],['Kiphire',613],['Phek',513],['Zunheboto',375],['Peren',276],['Longleng',217]],
work:[['Unemployed',83,'ochre'],['Self-employed',11,'green'],['Other or unspecified',6,'grey']],
parakh:[['More than half of students did family work after 10th',16],['More than half took a job immediately after 10th',9],['More than half repeated 10th',5]],
routes:['Resumed education','Moved for school','Paid work','Unpaid family work','Seeking work','Pursued sports','Another reason'],
reex:[['Arts',640,364],['Commerce',88,55],['Science',223,78]],
oos:[723,680,414],
// name, literacy 2011, NER 2024-25 [primary, upper, secondary, higher sec], govt schools 2023-24 [primary, middle, high, higher sec]
dist:[
['Dimapur',84.79,[138.80,92.37,72.33,62.74],[135,121,25,7]],
['Kiphire',69.54,[65.77,33.27,27.23,9.46],[55,33,16,2]],
['Kohima',85.23,[89.21,53.11,45.35,45.09],[85,50,23,9]],
['Longleng',72.17,[63.00,26.43,24.25,8.84],[51,18,15,1]],
['Mokokchung',91.62,[81.82,36.10,28.92,19.03],[105,51,37,5]],
['Mon',56.99,[79.29,36.38,24.75,10.20],[133,67,16,6]],
['Peren',77.95,[70.04,39.19,31.44,13.80],[71,43,14,4]],
['Phek',78.05,[50.72,29.26,21.74,8.74],[93,42,35,4]],
['Tuensang',73.08,[62.02,30.08,21.82,8.35],[105,58,27,5]],
['Wokha',87.69,[59.58,22.81,19.88,7.84],[78,44,17,4]],
['Zunheboto',85.26,[59.76,25.52,19.45,6.90],[115,79,21,5]]
].map(a=>({name:a[0],lit:a[1],ner:a[2],gov:a[3]})),
tiles:{Mokokchung:[1,0],Longleng:[2,0],Mon:[3,0],Wokha:[0,1],Zunheboto:[1,1],Tuensang:[2,1],Dimapur:[0,2],Kohima:[1,2],Kiphire:[2,2],Peren:[1,3],Phek:[2,3]},
ledger:[
 {c:'doc',tag:'Recorded · programme action',k:'5 schools',p:'Science was introduced at 5 existing government higher-secondary schools in September 2025.',l:'No retention or migration effect has been measured.'},
 {c:'nat',tag:'National provision · uptake not verified',k:'Up to ₹2,000',p:'Open-schooling support per eligible learner, per grade, per year, for ages 16–19.',l:'This is a national provision. Nagaland uptake is not verified.'},
 {c:'doc',tag:'Recorded · administrative figure',k:'37 of 170',p:'Uploaded dropouts were willing to continue through open distance learning and asked for assistance.',l:'This does not show later enrolment. The state reported no child in NIOS or SIOS in 2023–24.'},
 {c:'doc',tag:'Recorded · school-reported',k:'54% of schools',p:'Reporting schools offered career guidance in the higher grades.',l:'This is a share of schools, not of students.'},
 {c:'doc',tag:'Recorded · institution count',k:'9 polytechnics',p:'Polytechnic institutions were recorded in March 2025.',l:'Enrolment and later outcomes are Data unavailable in the records reviewed.'},
 {c:'inv',tag:'Investment project',k:'US$56.5 million',p:'World Bank NECTAR project covering 16 school complexes.',l:'This is separate from the school-access inventory. Effects are not yet measured.'}
]};
D.ledger2=[
 {k:'5 schools',p:'Science added at government higher-secondary schools, September 2025.',t:'Recorded · effect not measured'},
 {k:'₹2,000',p:'Up to this much per learner per year for open schooling, ages 16–19.',t:'National provision · Nagaland uptake not verified'},
 {k:'37 of 170',p:'Dropouts willing to continue through open distance learning.',t:'Administrative record · year not stated · later enrolment not shown'},
 {k:'54%',p:'of reporting schools offered career guidance in higher grades. In the 2018 leaver survey, 33 in 100 said guidance was enough to decide.',t:'School-reported share · plus 2018 survey'}];

/* additions: sourced figures added to close story gaps */
D.ger={'2024–25':{ng:[95.4,71.0,61.8,39.8],ind:[90.9,90.3,78.7,58.4]}}; // UDISE+ 2024–25 via The Morung Express, 7 Sept 2025
D.he={ger:[['2020–21',17.3],['2021–22',18.8],['2022–23',18.8],['2023–24',19.66],['2024–25',19.07]],f:21.7,m:16.5,enrol:48439}; // AISHE via Nagaland Higher Education Dept AAR 2025–26
D.ptr={ng:13,ind:24,single:0,prevSingle:31}; // UDISE+ 2024–25 via The Morung Express

D.lit={top:[{n:'Kerala',v:94.0},{n:'Mizoram',v:91.6},{n:'Goa',v:88.7},{n:'Tripura',v:87.8},{n:'Himachal Pradesh',v:83.8}],ng:{n:'Nagaland',v:79.55,hot:1}}; // literacy, age 7+, Census 2011 (final totals, rounded)
