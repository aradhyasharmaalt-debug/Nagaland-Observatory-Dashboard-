const ST={s2:'count',metric:'h',sel:'Kohima',yr4:'2025–26',cmp:false,hs:5,tree:'ug'};
const CMP={prev:'#FF8A6B'};
const SHORT={'Arunachal Pradesh':'AR','Mizoram':'MZ'};

/* ---- 01 rings: 100 ticks, one per percentage point ---- */
(function(){const I=[
 {t:'Literacy',m:'People aged 7+ who can read and write · 2011',v:79.55,i:73.0,bad:0,d:2},
 {t:'Higher secondary',m:'Net enrolment · 2025–26',v:26.3,i:39.0,bad:0,d:1},
 {t:'Dropout, 9th–10th',m:'Annual rate · 2025–26',v:13.3,i:9.5,bad:1,d:1}];
 $('#rings').innerHTML=I.map(o=>{const n=Math.round(o.v);let tk='';
  for(let k=0;k<100;k++){const a=(k*3.6-90)*Math.PI/180,c=Math.cos(a),s=Math.sin(a);tk+=`<line x1="${(110+80*c).toFixed(1)}" y1="${(110+80*s).toFixed(1)}" x2="${(110+100*c).toFixed(1)}" y2="${(110+100*s).toFixed(1)}" stroke-width="3.2" stroke-linecap="round" class="${k<n?(o.bad?'s-bad':'s-good'):'s-mute'}"/>`}
  return `<div class="ring" ${tp(o.t+', Nagaland',o.v+'%. '+o.m+'.')} tabindex="0"><svg viewBox="0 0 220 220" role="img" aria-label="${o.t}: Nagaland ${o.v}%">${tk}<text x="110" y="124" text-anchor="middle" class="num" style="font-size:46px">${o.v.toFixed(o.d)}<tspan style="font-size:20px" dx="2">%</tspan></text></svg><span class="lab">${o.t}</span><span class="mt">${o.m}</span></div>`}).join('')})();

/* ---- 02 stage towers / participation pillars ---- */
const STG=['cA','cB','cC','cD'],STGC=['#F5EBD8','#F3B52B','#7FD3A1','#FF8A6B'];
mount('v2',w=>{
 const R=Math.min(w/2-6,250),S=2*R+12,cx=R+6,cy=R+6,INK='#16110F';
 const side=w>760;
 if(ST.s2==='age')return ageView(w);
 if(ST.s2==='count'){const a=D.enrol['2025–26'],tot=a.reduce((x,y)=>x+y,0);
  $('#cap2').textContent='Each slice is a stage, sized by its share of enrolment. Primary covers five grades, so a larger slice does not mean more students are leaving.';
  $('#src2').textContent='UDISE+ 2025–26, students enrolled, all school managements, Nagaland. 2024–25 totals: 1,62,251 primary, 86,933 upper primary, 53,972 secondary, 36,670 higher secondary.';
  const cells=plate(a.map((v,i)=>({v,i})),R,cx,cy);
  let s=`<svg viewBox="0 0 ${S} ${S}" style="width:${S}px;max-width:100%;height:auto" role="img" aria-label="Enrolment by stage as a circle; area shows number of students">`;
  s+=`<circle cx="${cx}" cy="${cy}" r="${R+4}" fill="none" class="s-fg" stroke-width="3"/>`;
  cells.forEach(k=>{const st=D.stages[k.i],bw=Math.max(...k.poly.map(q=>q[0]))-Math.min(...k.poly.map(q=>q[0])),big=bw>200,fs=Math.min(64,Math.sqrt(k.area)/3.4,bw/3.2);
   s+=`<g ${tp(st.name+' ('+st.grades+')',nf(k.v)+' students, '+(k.v/tot*100).toFixed(1)+'% of all enrolled, 2025–26.')} tabindex="0"><path class="cell" d="${polyPath(k.poly)}" style="fill:${STGC[k.i]}" stroke="${INK}" stroke-width="5" stroke-linejoin="round"/>
   <text x="${k.c[0]}" y="${k.c[1]}" text-anchor="middle" style="font:400 ${fs}px var(--disp);fill:${INK}">${(k.v/tot*100).toFixed(0)}%</text>
   <text x="${k.c[0]}" y="${k.c[1]+fs*.5+6}" text-anchor="middle" style="font:800 ${Math.max(9,Math.min(13,fs/3.2))}px var(--body);letter-spacing:.1em;text-transform:uppercase;fill:${INK}">${big?st.name:st.name.split(' ')[0]}</text>
   <text x="${k.c[0]}" y="${k.c[1]+fs*.5+6+Math.max(11,Math.min(15,fs/3))}" text-anchor="middle" style="font:700 ${Math.max(9,Math.min(12,fs/3.4))}px var(--body);fill:${INK};opacity:.75">${nf(k.v)}</text></g>`});
  return `<div class="plate-wrap">${s}</svg></div>`}
 /* in school: fan, equal angles, radius = net enrolment rate; dashed outline = previous year; labels live in an HTML key */
 const d=D.ner['2025–26'],pv=D.ner['2024–25'],drops=d.ng.map((v,i)=>i?+(d.ng[i-1]-v).toFixed(1):0),mi=drops.indexOf(Math.max(...drops));
 $('#cap2').textContent=`${f1(d.ng[0])} in 100 at primary, ${f1(d.ng[1])} at upper primary. This is the steepest fall between stages.`;
 $('#src2').textContent='UDISE+ 2025–26, net enrolment rate: students of the official age group enrolled at a stage, divided by that age group\'s population. The outer ring is 100%. Dashed outline is 2024–25. Slices are equal in angle; the length of each slice is the rate.';
 const P=(a,r)=>[cx+r*Math.cos(a),cy+r*Math.sin(a)],sec=(a0,a1,r)=>{const[x0,y0]=P(a0,r),[x1,y1]=P(a1,r);return `M${cx} ${cy}L${x0} ${y0}A${r} ${r} 0 0 1 ${x1} ${y1}Z`};
 let s=`<svg viewBox="0 0 ${S} ${S}" style="width:${S}px;max-width:100%;height:auto" role="img" aria-label="Net enrolment rate by stage in Nagaland, 2025–26">`;
 [25,50,75,100].forEach(t=>s+=`<circle cx="${cx}" cy="${cy}" r="${R*t/100}" fill="none" class="s-soft" stroke-width="${t===100?2:1}" stroke-dasharray="${t===100?'0':'2 6'}"/>`);
 d.ng.forEach((v,i)=>{const a0=-Math.PI/2+i*Math.PI/2,a1=a0+Math.PI/2,hot=i===mi,r=R*v/100,ri=R*pv.ng[i]/100;
  s+=`<g ${tp(D.stages[i].name,'2025–26: '+f1(v)+'%. 2024–25: '+f1(pv.ng[i])+'%.')} tabindex="0"><path class="cell" d="${sec(a0+.02,a1-.02,r)}" style="fill:${hot?'url(#weaveR)':STGC[i]}" stroke="${INK}" stroke-width="3" stroke-linejoin="round"/><path d="${sec(a0+.02,a1-.02,ri)}" fill="none" class="s-fg" stroke-width="3" stroke-dasharray="7 5"/></g>`});
 const key=d.ng.map((v,i)=>{const hot=i===mi,ch=+(v-pv.ng[i]).toFixed(1);return `<div class="nk ${hot?'hot':''}" ${tp(D.stages[i].name,'2025–26: '+f1(v)+'%. 2024–25: '+f1(pv.ng[i])+'%.')}><i style="background:${hot?'var(--bad)':STGC[i]}"></i><b>${D.stages[i].name}</b><span class="big">${f1(v)}%</span><span class="in">2024–25: ${f1(pv.ng[i])}%</span><em>${ch>0?'+':ch<0?'−':''}${f1(Math.abs(ch))} pts on last year</em></div>`}).join('');
 return `<div class="plate-wrap">${s}</svg></div><div class="nkeys">${key}</div><p class="nhint"><span><i></i>Filled slice: 2025–26</span><span><i class="dsh"></i>Dashed outline: 2024–25</span><span>Outer ring is 100%</span></p>`});
bindSeg('tab2',v=>{ST.s2=v;redraw('v2')});

/* ---- 03 hex district map ---- */
const MET=[{k:'lit',b:'Literacy 2011',n:'Literacy 2011',get:d=>d.lit},{k:'p',b:'Primary',n:'Primary net enrolment',get:d=>d.ner[0]},{k:'u',b:'Upper primary',n:'Upper-primary net enrolment',get:d=>d.ner[1]},{k:'s',b:'Secondary',n:'Secondary net enrolment',get:d=>d.ner[2]},{k:'h',b:'Higher secondary',n:'Higher-secondary net enrolment',get:d=>d.ner[3]}];
const metric=()=>MET.find(m=>m.k===ST.metric);
function drawText3(){const m=metric(),r=D.dist.slice().sort((a,b)=>m.get(b)-m.get(a)),hi=r[0],lo=r[r.length-1],v=d=>f1(m.get(d))+'%';
 $('#h3').innerHTML=`${hi.name} <em>${v(hi)}</em><br>${lo.name} ${v(lo)}`;
 $('#sub3').textContent=m.n+(m.k==='lit'?' · Census 2011':' · 2024–25');
 const gap=f1(m.get(hi)-m.get(lo));
 $('#cap3').textContent=m.k==='h'?'Only Dimapur and Kohima are above 40%. The other nine range from 6.9% to 19.0%.':m.k==='p'?'Dimapur is above 100% because enrolment can include students from outside the district.':`${gap} percentage points separate the highest and lowest district.`}
function hexMap(w){const m=metric(),vals=D.dist.map(m.get),mn=Math.min(...vals),mx=m.k==='lit'?Math.max(...vals):Math.min(Math.max(...vals),100),r=w/7.9,hw=Math.sqrt(3)*r,H=r*6.6,fs=Math.max(9,Math.min(15,r*.19));
 let o=`<svg viewBox="0 0 ${w} ${H}" width="${w}" height="${H}" role="group" aria-label="Hexagon map of Nagaland districts coloured by ${m.n}" style="--ramp0:#EADBB8;--ramp1:#1D5A41">`;
 D.dist.forEach(d=>{const [c,rw]=D.tiles[d.name],cx=hw*(c+.5+(rw%2?.5:0))+2,cy=r*(1.5*rw+1)+2,v=m.get(d),t=Math.max(0,Math.min(1,(v-mn)/(mx-mn))),pts=[0,1,2,3,4,5].map(i=>{const a=(60*i-30)*Math.PI/180;return(cx+r*Math.cos(a)).toFixed(1)+','+(cy+r*Math.sin(a)).toFixed(1)}).join(' '),dark=t>.55;
  o+=`<g class="hex ${ST.sel===d.name?'sel':''}" data-d="${d.name}" tabindex="0" role="button" aria-label="${d.name}, ${f1(v)}%" ${tp(d.name,m.n+': '+f1(v)+'%.')}><polygon points="${pts}" style="fill:color-mix(in srgb,var(--ramp1) ${(t*100).toFixed(0)}%,var(--ramp0))"/><text x="${cx}" y="${cy-fs*.7}" text-anchor="middle" style="font-size:${fs}px;fill:${dark?'#F5EBD8':'#16110F'}">${d.name}</text><text x="${cx}" y="${cy+fs*1.2}" text-anchor="middle" style="font-family:var(--disp);font-weight:400;font-size:${fs*1.5}px;fill:${dark?'#F5EBD8':'#16110F'}">${f1(v)}${v>100?'*':''}</text></g>`});
 return o+`</svg><div class="ramp" style="--ramp0:#EADBB8;--ramp1:#1D5A41"></div><div class="rampl"><span>${f1(mn)}%</span><span>DARKER = HIGHER</span><span>${f1(mx)}%</span></div>`}
function panel3(){const d=D.dist.find(x=>x.name===ST.sel),m=metric();
 return `<div class="panel"><h3 class="h4like">${d.name}</h3><div class="lab" style="margin-top:4px;opacity:.75">Net enrolment by stage · 2024–25</div><div class="stairs">${D.stages.map((s,i)=>{const v=d.ner[i];return `<div><b>${f1(v)}${v>100?'*':''}</b><i class="bar ${m.k===s.k?'on':''}" style="height:${Math.min(v,100)*.95}px;display:block"></i><span>${s.name.replace('Higher secondary','Higher sec.').replace('Upper primary','Upper pri.')}</span></div>`}).join('')}</div><div class="lab" style="margin-top:12px">Literacy 2011 <b style="font-family:var(--disp);font-size:20px;letter-spacing:.02em;margin-left:6px">${f1(d.lit)}%</b></div>${d.ner[0]>100?'<p style="font-size:12px;margin:8px 0 0">*Above 100%: can include students from outside the district.</p>':''}</div>`}
function draw3(){drawText3();$('#panel3').innerHTML=panel3();redraw('v3')}
mount('v3',hexMap);
pills('pills3',MET.map(m=>({v:m.k,t:m.b})),ST.metric,v=>{ST.metric=v;draw3()});
document.addEventListener('click',e=>{const t=e.target.closest('[data-d]');if(t){ST.sel=t.dataset.d;draw3()}});
document.addEventListener('keydown',e=>{if((e.key==='Enter'||e.key===' ')&&e.target.matches&&e.target.matches('[data-d]')){e.preventDefault();ST.sel=e.target.dataset.d;draw3();const n=$(`[data-d="${ST.sel}"]`);n&&n.focus()}});
draw3();

/* ---- 04 houses: 100 students per step, roof + horns ---- */
function houseSVG(rate,key,label){const n=Math.round(rate),items=[{k:'c',col:'var(--good)',v:n},{k:'n',col:'var(--mute)',v:100-n}];
 const cnt=alloc(items.map(i=>i.v),100);let cells='',idx=0;
 // fill from bottom: reverse row order so the empty part sits at the top
 for(let k=0;k<100;k++){const filled=k<cnt[0],pos=99-k,x=5+(pos%10)*11,y=2+Math.floor(pos/10)*11;cells+=`<use href="#p" class="cell" x="${x}" y="${y}" width="10" height="10" style="fill:${filled?'var(--good)':'var(--mute)'};animation-delay:${Math.min(k*5,400)}ms" data-tip="${esc((filled?'Continued':'Did not continue in the record')+'|'+label)}"/>`}
 let lines='';if(ST.cmp){const oy=ST.yr4==='2025–26'?'2024–25':'2025–26',v=D.tr[oy].Nagaland[key],y=2+(1-v/100)*110;lines=`<line x1="0" x2="124" y1="${y}" y2="${y}" stroke="${CMP.prev}" stroke-width="2" stroke-dasharray="5 3"/><g ${tp('Nagaland, '+oy,f1(v)+'% continued, '+label)}><circle cx="124" cy="${y}" r="4" fill="${CMP.prev}"/></g>`}
 return `<svg viewBox="-4 -46 136 ${46+114}" role="img" aria-label="${label}: ${rate} of every 100 continued"><use href="#horns" x="44" y="-46" width="32" height="19" fill="var(--hi)"/><polygon points="-4,-2 60,-32 124,-2" fill="var(--hi)"/><rect x="1" y="-2" width="118" height="116" fill="none" class="s-fg" stroke-width="2"/>${cells}${lines}</svg>`}
mount('v4',w=>{const d=D.tr[ST.yr4],ng=d.Nagaland;
 $('#giant').innerHTML=`${f1(ng[2])}<small>%</small>`;
  $('#cap4').textContent=`Lowest of the three steps, and below India's ${f1(D.tr[ST.yr4].India[2])}. After Class 5, ${f1(ng[0])} in 100 carried on. After Class 8, ${f1(ng[1])}. (${ST.yr4})`;
 return `<div class="houses">${D.trSteps.map((s,i)=>`<div class="house ${i===2?'low':''}" ${tp('Nagaland, '+ST.yr4,f1(ng[i])+'% continued from '+s[0]+'.')}>${houseSVG(ng[i],i,s[0])}<div class="t">${f1(ng[i])}%</div><div class="s">${s[0]}</div>${i===2?'<div class="hand" style="position:absolute;right:0;top:6%;font-size:clamp(1.2rem,2.4vw,2rem)">lowest step ↓</div>':''}</div>`).join('')}</div><p class="lab" style="margin-top:18px;opacity:.8">Picture 100 students at the start of each step. Green people carried on.${ST.cmp?' Dashed line: the other year.':''}</p>`});
bindSeg('yr4',v=>{ST.yr4=v;redraw('v4')});
(function(){const el=$('#cmp4');el.innerHTML='<button type="button" aria-pressed="false">Compare with the other year</button>';el.onclick=e=>{const b=e.target.closest('button');if(!b)return;ST.cmp=!ST.cmp;b.setAttribute('aria-pressed',ST.cmp);redraw('v4')}})();

/* ---- 04a woven towers: pass rates, scrub by year ---- */
let towerNow={g:D.hslc.gov[5],p:D.hslc.priv[5]},towerRaf=0;
function towerSVG(w,g,p){const H=300,tw=Math.min(150,w*.3),gap=Math.min(60,w*.1),x0=(w-2*tw-gap)/2,Y=v=>46+(H-46-34)*(1-v/100),yb=Y(0);
 const t=(x,v,fill,lab,clr)=>`<g><rect x="${x}" y="${Y(v)}" width="${tw}" height="${yb-Y(v)}" style="fill:${fill}"/><polygon points="${x-8},${Y(v)} ${x+tw/2},${Y(v)-30} ${x+tw+8},${Y(v)}" style="fill:${clr}"/><text x="${x+tw/2}" y="${Y(v)-40}" text-anchor="middle" class="num" style="font-size:44px">${v.toFixed(0)}%</text><text x="${x+tw/2}" y="${H-8}" text-anchor="middle" class="lab">${lab}</text></g>`;
 return `<svg viewBox="0 -4 ${w} ${H+4}" width="${w}" height="${H+4}" role="img" aria-label="Class 10 pass rate: government ${g.toFixed(0)} percent, private ${p.toFixed(0)} percent">${t(x0,g,'url(#weaveR)','Government','#FF5A4A')}${t(x0+tw+gap,p,'#F5EBD8','Private','#F3B52B')}<line x1="0" x2="${w}" y1="${yb}" y2="${yb}" class="s-fg" stroke-width="3"/></svg>`}
mount('v4a',w=>{const i=ST.hs,h=D.hslc;$('#h4a').innerHTML=`Class 10 pass rate <em>${h.years[i]}</em>`;$('#yl4a').innerHTML=h.years.map(y=>`<span>${y}</span>`).join('');
 return `<div ${tp('Class 10 pass rate, '+h.years[i],'Government '+f2(h.gov[i])+'%. Private '+f2(h.priv[i])+'%.')} tabindex="0">${towerSVG(w,towerNow.g,towerNow.p)}</div>`});
$('#yr4a').addEventListener('input',e=>{ST.hs=+e.target.value;const h=D.hslc,tg=h.gov[ST.hs],tpv=h.priv[ST.hs],o={...towerNow},t0=performance.now();cancelAnimationFrame(towerRaf);$('#h4a').innerHTML=`Class 10 pass rate <em>${h.years[ST.hs]}</em>`;
 const step=n=>{const k=Math.min(1,(n-t0)/350),e2=1-Math.pow(1-k,3);towerNow={g:o.g+(tg-o.g)*e2,p:o.p+(tpv-o.p)*e2};redraw('v4a');if(k<1)towerRaf=requestAnimationFrame(step)};towerRaf=requestAnimationFrame(step)});

/* ---- 04b dropout arrows ---- */
mount('v4b',w=>{const d=D.drop,names=['Nagaland','India'],ng=d.Nagaland;
 $('#h4b').innerHTML=ng[1]>ng[0]?`Dropout rose to <em>${f1(ng[1])}%</em>, while India's fell to ${f1(d.India[1])}%`:`Dropout ${f1(ng[1])}%`;
 const COL={'Nagaland':'var(--hi)','India':'var(--fg)'};
 const L=Math.min(150,w*.34),R=Math.min(70,w*.18),H=330,top=30,bot=44,Y=v=>top+(H-top-bot)*(1-(v-6)/(20-6)),x0=L,x1=w-R;
 const spread=(vals)=>{const o=vals.map((v,i)=>({i,y:Y(v)})).sort((a,b)=>a.y-b.y);for(let k=1;k<o.length;k++)if(o[k].y-o[k-1].y<21)o[k].y=o[k-1].y+21;const r=[];o.forEach(q=>r[q.i]=q.y);return r};
 const ly=spread(names.map(n=>d[n][0])),ry=spread(names.map(n=>d[n][1]));
 let s=`<svg viewBox="0 0 ${w} ${H}" width="${w}" height="${H}" role="img" aria-label="Secondary dropout rate, 2024–25 to 2025–26, three places. Axis from 6 to 20 percent">`;
 [8,12,16,20].forEach(t=>s+=`<line x1="${x0}" x2="${x1}" y1="${Y(t)}" y2="${Y(t)}" class="s-soft" stroke-width="1" stroke-dasharray="2 6"/>`);
 s+=`<text x="${x0}" y="16" text-anchor="middle" class="lab" style="font-size:14px">2024–25</text><text x="${x1}" y="16" text-anchor="middle" class="lab" style="font-size:14px">2025–26</text>`;
 names.slice().reverse().forEach(n=>{const i=names.indexOf(n),v=d[n],hot=i===0,col=COL[n],lab=n==='Arunachal Pradesh'&&w<460?'Arunachal':n;
  s+=`<g ${tp(n+', secondary dropout','2024–25: '+f1(v[0])+'%. 2025–26: '+f1(v[1])+'%. Change '+sgn(v[1]-v[0])+f1(Math.abs(v[1]-v[0]))+' percentage points.')} tabindex="0"><line x1="${x0}" y1="${Y(v[0])}" x2="${x1}" y2="${Y(v[1])}" stroke="${col}" stroke-width="${hot?8:4}" stroke-linecap="round" ${hot?'':'opacity=".9"'}/><circle cx="${x0}" cy="${Y(v[0])}" r="${hot?9:6}" fill="${col}"/><circle cx="${x1}" cy="${Y(v[1])}" r="${hot?9:6}" fill="${col}"/>
  <text x="${x0-16}" y="${ly[i]+5}" text-anchor="end" style="font:${hot?800:700} ${hot?16:14}px var(--body);fill:${col}">${lab} <tspan style="font-family:var(--disp);font-weight:400;font-size:${hot?22:18}px">${f1(v[0])}</tspan></text>
  <text x="${x1+16}" y="${ry[i]+6}" style="font:400 ${hot?26:20}px var(--disp);fill:${col}">${f1(v[1])}</text></g>`});
 return s+`</svg><p class="lab" style="margin-top:6px;text-transform:none;letter-spacing:0;font-size:14px;opacity:.85">A line that climbs means dropout went up.</p>`});

/* ---- 04c where each place sits at each step ---- */
mount('v4c',w=>{const names=['2024–25','2025–26'],get=(n,k)=>D.tr[n].Nagaland[k],L=w<560?0:130,rh=w<560?88:78,top=14,H=top+rh*3+34,X=v=>L+14+(w-L-34)*(v-50)/50;
 const COL={'2025–26':'var(--hi)','2024–25':CMP.prev};
 let s=`<svg viewBox="0 0 ${w} ${H}" width="${w}" height="${H}" role="img" aria-label="Share of students continuing at each step in Nagaland, 2024–25 and 2025–26. Axis starts at 50 percent">`;
 [50,60,70,80,90,100].forEach(t=>s+=`<line x1="${X(t)}" x2="${X(t)}" y1="${top}" y2="${H-26}" class="s-soft" stroke-width="1" stroke-dasharray="2 6"/><text x="${X(t)}" y="${H-8}" text-anchor="middle" class="lab" style="font-size:12px;opacity:.8">${t}</text>`);
 D.trSteps.forEach((st,k)=>{const cy=top+rh*k+rh/2+(w<560?14:0),vals=names.map(n=>get(n,k)),mn=Math.min(...vals),mx=Math.max(...vals),low=k===2;
  s+=`<text x="0" y="${w<560?cy-34:cy+6}" style="font:400 ${low?24:20}px var(--disp);letter-spacing:.02em;fill:${low?'var(--hi)':'var(--fg)'}">${st[0]}</text>`;
  s+=`<line x1="${X(mn)}" x2="${X(mx)}" y1="${cy}" y2="${cy}" class="s-soft" stroke-width="10" stroke-linecap="round" opacity=".5"/>`;
  names.forEach(n=>{const v=get(n,k),hot=n==='2025–26';
   s+=`<g ${tp('Nagaland, '+n,f1(v)+'% continued. '+st[1]+'.')} tabindex="0"><circle cx="${X(v)}" cy="${cy}" r="${hot?15:9}" fill="${COL[n]}" ${hot?'stroke="var(--fg)" stroke-width="3"':''}/>${hot?`<text x="${X(v)}" y="${cy-24}" text-anchor="middle" style="font:400 26px var(--disp);fill:var(--hi)">${f1(v)}</text>`:''}</g>`})});
 return s+'</svg>'});

/* ---- 05 what makes it hard ---- */
(function(){const A=D.acc,hs=A[3];$('#h5').innerHTML=`<em>${Math.round(hs.pc)}%</em> of villages lack higher-secondary access`;
 /* distance: 100 villages per stage, red = no school within the prescribed distance */
 const sym=`<svg width="0" height="0" style="position:absolute" aria-hidden="true"><defs><symbol id="vh-ok" viewBox="0 0 20 21"><path fill-rule="evenodd" d="M10 0 20 8V21H0V8ZM7.5 21V14H12.5V21Z"/></symbol><symbol id="vh-no" viewBox="0 0 20 21"><path d="M10 0 20 8V21H0V8Z"/></symbol><symbol id="pp" viewBox="0 0 20 30"><circle cx="10" cy="6" r="5.5"/><path d="M2 30V18C2 13 5.5 12 10 12S18 13 18 18V30Z"/></symbol></defs></svg>`;
 const rowHtml=(a,i)=>{const r=Math.round(a.pc),ok=100-r,hl=i===3;let hs='';for(let k=0;k<100;k++){const no=k>=ok;hs+=`<svg class="vh ${no?'no':'ok'}" style="--d:${no?(k-ok)*14:0}ms" aria-hidden="true"><use href="#vh-${no?'no':'ok'}"/></svg>`}
  return `<div class="vrow ${hl?'hl':''}" ${tp(a.name+' schools',nf(a.n)+' villages had no school within the prescribed distance ('+f2(a.pc)+'% of those assessed).')} tabindex="0" role="img" aria-label="${a.name}: ${f2(a.pc)} percent of villages assessed have no school within the prescribed distance"><div class="vl"><span class="vn">${a.name}</span><b class="vp">${r}<small>%</small></b><span class="vs">no school in reach</span></div><div class="vh-wrap">${hs}</div></div>`};
 $('#v5').innerHTML=sym+`<div class="vf">${A.map(rowHtml).join('')}</div><div class="vkey"><span><svg class="vh ok" aria-hidden="true"><use href="#vh-ok"/></svg>School within reach</span><span><svg class="vh no" aria-hidden="true"><use href="#vh-no"/></svg>No school within the prescribed distance</span><span class="vk1">1 house = 1 in 100 villages assessed</span></div>`;
 const goIO=new IntersectionObserver(es=>es.forEach(e=>{if(e.isIntersecting){e.target.classList.add('go');goIO.unobserve(e.target)}}),{threshold:.3});
 $$('#v5 .vf').forEach(e=>goIO.observe(e));
 /* ladder: government schools by stage, 11 districts */
 const tot=[0,1,2,3].map(k=>D.dist.reduce((a,d)=>a+d.gov[k],0)),mx=tot[0],NM=['Primary','Middle','High','Higher secondary'];$('#h5c').innerHTML=`<em style="color:var(--bad)">${nf(tot[0])}</em> government primary schools, against <em style="color:var(--bad)">${nf(tot[3])}</em> government higher secondary.`;
 $('#v5c').innerHTML=`<div class="ladder">${tot.map((t,k)=>`<div class="rung ${k===3?'hl':''}" ${tp(NM[k]+' schools',nf(t)+' government schools in the 11 districts reporting, 2023–24.')} tabindex="0"><span class="nm">${NM[k]}</span><span class="bar"><i style="width:${Math.max(2.5,t/mx*100)}%"></i></span><span class="ct">${nf(t)}</span></div>`).join('')}</div>`;
 /* reasons: a crowd of 100 leavers, grouped by reason */
 const wc=['#C4162C','#16110F','#1D5A41','#3B5BDB','rgba(22,17,15,.32)'];let ppl='',kk=0;
 D.why.forEach((r,k)=>{for(let q=0;q<r[1];q++){ppl+=`<svg class="pp" data-k="${k}" style="fill:${wc[k]};--d:${(kk++)*9}ms" aria-hidden="true"><use href="#pp"/></svg>`}});
 $('#v5b').innerHTML=`<div class="crowd" id="crowd" role="img" aria-label="100 former students, grouped by the reason they gave: ${D.why.map(r=>r[0]+' '+r[1]).join(', ')}">${ppl}</div><div class="ckey">${D.why.map((r,k)=>`<button type="button" class="ck ${k===0?'top':''}" data-k="${k}" ${tp(r[0],r[1]+' of every 100 former students surveyed in 2018 (871 surveyed).')}><svg class="pp" style="fill:${wc[k]}" aria-hidden="true"><use href="#pp"/></svg><b>${r[1]}</b><span>${r[0]}</span></button>`).join('')}</div>`;
 const cr=$('#crowd');$$('.ck').forEach(b=>{const on=()=>cr.dataset.hl=b.dataset.k,off=()=>delete cr.dataset.hl;b.addEventListener('mouseenter',on);b.addEventListener('focus',on);b.addEventListener('mouseleave',off);b.addEventListener('blur',off)});
 goIO.observe(cr);
})();

/* ---- 06 treemap ---- */
function squarify(items,x,y,w,h){const tot=items.reduce((a,i)=>a+i.v,0),out=[];let rest=items.map(i=>({...i,a:i.v/tot*w*h}));
 const worst=(r,side)=>{const s=r.reduce((a,q)=>a+q.a,0),mx=Math.max(...r.map(q=>q.a)),mn=Math.min(...r.map(q=>q.a));return Math.max(side*side*mx/(s*s),s*s/(side*side*mn))};
 while(rest.length){const side=Math.min(w,h);let row=[rest[0]],i=1;while(i<rest.length&&worst(row.concat(rest[i]),side)<=worst(row,side)){row.push(rest[i]);i++}
  rest=rest.slice(row.length);const s=row.reduce((a,q)=>a+q.a,0);
  if(w>=h){const rw=s/h;let cy=y;row.forEach(q=>{const rh=q.a/rw;out.push({...q,x,y:cy,w:rw,h:rh});cy+=rh});x+=rw;w-=rw}else{const rh=s/w;let cx=x;row.forEach(q=>{const rw=q.a/rh;out.push({...q,x:cx,y,w:rw,h:rh});cx+=rw});y+=rh;h-=rh}}
 return out}
const TREE={ug:{rows:D.ug,unit:'undergraduates',strong:2,h:t=>`<em style="color:var(--bad)">${Math.round(t)}%</em> of undergraduates study in Dimapur or Kohima`,
  cap:'College location is not where students live. The records do not show how many travel or move.',
  src:'Nagaland Statistical Handbook 2025, table 20.3. Undergraduates by institution district, 2023–24, 38,744 students. Dimapur and Kohima also hosted 79.3% of students across all higher-education levels.'},
 mv:{rows:D.mv,unit:'moves',strong:3,h:t=>`<em style="color:var(--bad)">${Math.round(t)}%</em> of education moves went to Kohima, Dimapur or Mokokchung`,
  cap:'14,277 rural-to-urban moves for education, 2011 boundaries. The data do not show school or college.',
  src:'Census of India 2011, migration table D-03. Rural-to-urban moves within Nagaland for education, by destination district, historic boundaries.'}};
mount('v6',w=>{const T=TREE[ST.tree],rows=T.rows.slice().sort((a,b)=>b[1]-a[1]),tot=rows.reduce((a,b)=>a+b[1],0),R=Math.min(w/2-6,270),S=2*R+12,top=rows.slice(0,T.strong).reduce((a,b)=>a+b[1],0)/tot*100;
 $('#h6').innerHTML=T.h(top);$('#cap6').textContent=T.cap;$('#src6').textContent=T.src;
 const cells=plate(rows.map((r,i)=>({n:r[0],v:r[1],i})),R,R+6,R+6),INK='#16110F';
 return `<div class="plate-wrap"><svg viewBox="0 0 ${S} ${S}" style="width:${S}px;max-width:100%;height:auto" role="img" aria-label="Circle divided by district, area shows ${T.unit}"><circle cx="${R+6}" cy="${R+6}" r="${R+4}" fill="none" class="s-fg" stroke-width="3"/>${cells.map(k=>{const strong=k.i<T.strong,share=(k.v/tot*100),sq=Math.sqrt(k.area),fs0=strong?Math.min(46,sq/4.2):Math.min(15,sq/4.2),fs=strong?Math.min(fs0,sq*.78/(k.n.length*.58)):fs0,fits=k.n.length*fs*.7<sq*.8&&fs>=12;
  return `<g ${tp(k.n,nf(k.v)+' '+T.unit+' ('+share.toFixed(1)+'%).')} tabindex="0"><path class="cell" d="${polyPath(k.poly)}" style="fill:${strong?'var(--good)':'#E7D6B3'}" stroke="${INK}" stroke-width="5" stroke-linejoin="round"/>${fits?`<text x="${k.c[0]}" y="${k.c[1]}" text-anchor="middle" style="font:400 ${fs}px var(--disp);letter-spacing:.02em;text-transform:uppercase;fill:${strong?'#F5EBD8':INK}">${k.n}</text><text x="${k.c[0]}" y="${k.c[1]+Math.max(13,fs*.5)+2}" text-anchor="middle" style="font:800 ${Math.max(12,Math.min(16,fs*.4))}px var(--body);fill:${strong?'#F5EBD8':INK}">${share.toFixed(share<10?1:0)}%</text>`:''}</g>`}).join('')}</svg></div>`});
bindSeg('tab6',v=>{ST.tree=v;redraw('v6')});

/* ---- 06a sun arc of plans ---- */
(function(){const tot=D.plan.reduce((a,b)=>a+b[1],0),cols=['var(--good)','var(--hi)','#16110F','#3B5BDB','#FF8A6B','rgba(22,17,15,.3)'],R=170,r=104,cx=180,cy=180;let a0=Math.PI,seg='',items=[];
 D.plan.forEach((p,i)=>{const a1=a0+p[1]/tot*Math.PI,P=(a,rr)=>[cx+rr*Math.cos(a),cy+rr*Math.sin(a)],[x0,y0]=P(a0,R),[x1,y1]=P(a1,R),[x2,y2]=P(a1,r),[x3,y3]=P(a0,r),lg=a1-a0>Math.PI?1:0;
  seg+=`<path class="cell" data-seg="p${i}" ${tp(p[0],nf(p[1])+' of '+nf(tot)+' listed answers ('+(p[1]/tot*100).toFixed(1)+'%).')} d="M${x0} ${y0}A${R} ${R} 0 ${lg} 1 ${x1} ${y1}L${x2} ${y2}A${r} ${r} 0 ${lg} 0 ${x3} ${y3}Z" style="fill:${cols[i]}" stroke="var(--bg)" stroke-width="2"/>`;
  items.push({k:'p'+i,col:cols[i],t:p[0],val:(p[1]/tot*100).toFixed(1)+'%',tip:p[0]+'|'+nf(p[1])+' of '+nf(tot)+' listed answers.'});a0=a1});
 let rays='';for(let k=0;k<=36;k++){const a=Math.PI+k*Math.PI/36;rays+=`<line x1="${cx+(R+8)*Math.cos(a)}" y1="${cy+(R+8)*Math.sin(a)}" x2="${cx+(R+(k%3?16:24))*Math.cos(a)}" y2="${cy+(R+(k%3?16:24))*Math.sin(a)}" stroke-width="3" stroke-linecap="round" class="s-fg" opacity=".35"/>`}
 $('#v6a').innerHTML=`<svg viewBox="-20 -20 400 230" style="max-width:440px;width:100%" role="img" aria-label="Planned next step of Class 12 students: 79.8 percent higher education">${rays}${seg}<text x="${cx}" y="${cy-6}" text-anchor="middle" class="num" style="font-size:58px">${(D.plan[0][1]/tot*100).toFixed(1)}%</text></svg>`+legend(items)})();

/* ---- 06b unknown routes ---- */
mount('v6b',w=>{const R=D.routes,rh=40,H=36+R.length*rh;let s=`<svg viewBox="0 0 ${w} ${H}" width="${w}" height="${H}" role="img" aria-label="Seven routes after 12th, all marked data unavailable"><rect x="0" y="0" width="150" height="26" rx="13" class="f-fg"/><text x="75" y="18" text-anchor="middle" class="lab" style="fill:var(--bg)">Leaves 11th–12th</text><line x1="14" y1="26" x2="14" y2="${36+(R.length-1)*rh+rh/2}" class="s-fg" stroke-width="3"/>`;
 R.forEach((r,i)=>{const cy=36+i*rh+rh/2;s+=`<g ${tp(r,'Not available. The public records reviewed do not track this outcome.')} tabindex="0"><path d="M14 ${cy}H50" fill="none" class="s-fg" stroke-width="2.5" stroke-dasharray="4 5"/><circle cx="68" cy="${cy}" r="15" fill="none" class="s-fg" stroke-width="2.5" stroke-dasharray="3 5"/><text x="68" y="${cy+7}" text-anchor="middle" class="num" style="font-size:20px">?</text><text x="94" y="${cy+5}" class="lab" style="font-size:12px">${r}</text></g>`});
 return s+'</svg>'});

/* ---- 06c work barcode ---- */
(function(){const cols=['var(--bad)','var(--good)','rgba(22,17,15,.28)'],items=D.work.map((r,i)=>({k:'k'+i,col:cols[i],v:r[1],t:r[0],val:r[1]+'%',tip:`${r[0]}|${r[1]}% of 871 former students in 2018.`})),cnt=alloc(items.map(i=>i.v),100);let b='',idx=0;
 items.forEach((it,si)=>{for(let k=0;k<cnt[si];k++,idx++)b+=`<i data-seg="${it.k}" data-tip="${esc(it.tip)}" style="background:${it.col};transform:scaleY(${.78+((idx*7)%5)*.055})"></i>`});
 $('#v6c').innerHTML=`<div class="barcode" role="img" aria-label="Work status: 83 unemployed, 11 self-employed, 6 other or unspecified, per 100 respondents">${b}</div>`+legend(items)})();

/* ---- 07 re-exam dots ---- */
mount('v7',w=>{const step=w<520?11:14,d=step-4,cols=Math.floor(w/step),cl=['#F5EBD8','#F5EBD8','#F5EBD8'];let y=0,s='';
 D.reex.forEach((r,ri)=>{const [name,n,pass]=r,rows=Math.ceil(n/cols);s+=`<text x="0" y="${y+18}" class="num" style="font-size:26px">${name} <tspan style="font-size:18px;opacity:.8">${pass} of ${n} · ${(pass/n*100).toFixed(0)}%</tspan></text>`;y+=30;
  let dots='';for(let k=0;k<n;k++){const ok=k<pass;dots+=`<circle cx="${(k%cols)*step+d/2}" cy="${y+Math.floor(k/cols)*step+d/2}" r="${d/2}" class="${ok?'f-good':'f-mute'}"/>`}
  s+=`<g class="wf" ${tp(name+', 2023',pass+' of '+n+' candidates qualified ('+(pass/n*100).toFixed(2)+'%). '+(n-pass)+' did not qualify.')} tabindex="0">${dots}</g>`;y+=rows*step+20});
 return `<svg viewBox="0 0 ${w} ${y}" width="${w}" height="${y}" role="img" aria-label="951 candidates in the 2023 Class 12 compartmental examination, 497 passed">${s}</svg><ul class="legend"><li><i style="background:var(--good);display:inline-block"></i> Qualified</li><li><i style="background:var(--mute);display:inline-block"></i> Did not qualify</li></ul>`});
(function(){const t=D.reex.reduce((a,r)=>a+r[1],0),p=D.reex.reduce((a,r)=>a+r[2],0);$('#h7').innerHTML=`<em>${p}</em> of ${t} passed the re-exam`})();
(function(){const [a,b,c]=D.oos,row=(n,t,w,cls)=>`<div class="row" ${tp(t,n+' children.')} tabindex="0"><span>${t}</span><div class="tr"><div style="width:${w/a*100}%;background:${cls};color:${cls==='#F5EBD8'?'#16110F':'#F5EBD8'}">${n}</div>${w===c?`<div class="ghost" style="width:${(a-c)/a*100}%">${a-c} not stated</div>`:''}</div></div>`;
 $('#v7b').innerHTML=`<div class="rows">${row(a,'Identified 2019–20',a,'#16110F')}${row(b,'Received training',b,'#16110F')}${row(c,'Mainstreamed 2020–21',c,'#F5EBD8')}</div>`})();
$('#ledger').innerHTML=D.ledger2.map(l=>`<article class="chip"><div class="k">${l.k}</div><p>${l.p}</p><small>${l.t}</small></article>`).join('');
