/* nav dots, rail, reveal, hero parallax */
(function(){const secs=$$('.sc'),dots=$('#dots');
 const PN=['See','Act','Fill the gaps'],PM=[0,0,0,0,1,1,1,2],pe=$('#parts');
 pe.innerHTML=PN.map((p,pi)=>{const ix=secs.map((s,i)=>PM[i]===pi?i:-1).filter(i=>i>=0);return `<div class="part" data-p="${pi}" style="flex:${ix.length} 1 auto"><a class="part-l" href="#${secs[ix[0]].id}">${p}</a><div class="segs">${ix.map(i=>`<a class="seg" href="#${secs[i].id}" aria-label="${secs[i].dataset.title}" title="${secs[i].dataset.title}"><span class="sn">${i+1}</span></a>`).join('')}</div></div>`}).join('');
 const links=$$('.seg',pe),rn=$('#railno'),prog=$('#prog');
 const upd=()=>{const h=document.documentElement;prog.style.transform=`scaleX(${Math.min(1,scrollY/Math.max(1,h.scrollHeight-innerHeight))})`};addEventListener('scroll',upd,{passive:true});upd();
 const io=new IntersectionObserver(es=>es.forEach(e=>{if(e.isIntersecting){const i=secs.indexOf(e.target);links.forEach((l,j)=>{l.classList.toggle('cur',j===i);l.classList.toggle('done',j<i)});$$('.part',pe).forEach(p=>p.classList.toggle('cur',+p.dataset.p===PM[i]));rn.textContent=String(i+1).padStart(2,'0')+' / '+String(secs.length).padStart(2,'0')}}),{rootMargin:'-45% 0px -50% 0px'});
 secs.forEach(s=>io.observe(s));
 const rv=new IntersectionObserver(es=>es.forEach(e=>{if(e.isIntersecting){e.target.classList.add('in');rv.unobserve(e.target)}}),{threshold:.15});
 $$('.mini-h,.nir,.bridge,.beat,.cap,.tabs,.pills,.flag,.viz:not(.rings)').forEach(el=>el.classList.add('rv'));
 $$('.rv').forEach(el=>rv.observe(el));
 const hero=$('#top'),bw=$('.big-word'),hb=$('.hb-fly');let tick=false;
 if(!matchMedia('(prefers-reduced-motion:reduce)').matches)addEventListener('scroll',()=>{if(tick)return;tick=true;requestAnimationFrame(()=>{const y=Math.min(scrollY,900);bw.style.translate=`0 ${y*.18}px`;hb.style.translate=`${-y*.35}px ${y*.12}px`;tick=false})},{passive:true});
})();
/* v9: 12px floor for SVG labels at the rendered size */
(function(){const fix=()=>{document.querySelectorAll('svg text').forEach(t=>{try{const m=t.getScreenCTM();if(!m)return;const k=Math.hypot(m.a,m.b)||1;const fs=parseFloat(getComputedStyle(t).fontSize);if(fs*k<11.9&&!t.dataset.fx){t.dataset.fx=1;t.style.fontSize=(12/k).toFixed(2)+'px'}}catch(e){}})};
 let q;const go=()=>{clearTimeout(q);q=setTimeout(fix,250)};addEventListener('load',()=>{go();setTimeout(fix,1500)});addEventListener('resize',()=>{document.querySelectorAll('svg text[data-fx]').forEach(t=>{t.style.fontSize='';delete t.dataset.fx});go()});
 new MutationObserver(go).observe(document.body,{childList:true,subtree:true})})();
