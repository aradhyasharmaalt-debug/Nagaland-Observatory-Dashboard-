/* exact-area circular partition ("plate"): recursive chord cuts of a circle, cell area = value */
function plate(items,R,cx,cy){
 const N=96,circ=[];for(let i=0;i<N;i++){const a=i/N*2*Math.PI;circ.push([cx+R*Math.cos(a),cy+R*Math.sin(a)])}
 const area=p=>{let s=0;for(let i=0;i<p.length;i++){const[a,b]=p[i],[c,d]=p[(i+1)%p.length];s+=a*d-c*b}return Math.abs(s)/2};
 const cent=p=>{let x=0,y=0,A=0;for(let i=0;i<p.length;i++){const[a,b]=p[i],[c,d]=p[(i+1)%p.length],k=a*d-c*b;A+=k;x+=(a+c)*k;y+=(b+d)*k}return[x/(3*A),y/(3*A)]};
 const clip=(p,ax,c,keepLow)=>{const out=[],inside=q=>keepLow?q[ax]<=c:q[ax]>=c;for(let i=0;i<p.length;i++){const a=p[i],b=p[(i+1)%p.length],ia=inside(a),ib=inside(b);if(ia)out.push(a);if(ia!==ib){const t=(c-a[ax])/(b[ax]-a[ax]);out.push(ax?[a[0]+t*(b[0]-a[0]),c]:[c,a[1]+t*(b[1]-a[1])])}}return out};
 const cells=[];
 (function split(its,poly){
  if(its.length===1){const A=area(poly);cells.push({...its[0],poly,area:A,c:cent(poly)});return}
  const s=its.slice().sort((a,b)=>b.v-a.v);let A=[],B=[],sa=0,sb=0;s.forEach(i=>{if(sa<=sb){A.push(i);sa+=i.v}else{B.push(i);sb+=i.v}});
  const xs=poly.map(q=>q[0]),ys=poly.map(q=>q[1]),w=Math.max(...xs)-Math.min(...xs),h=Math.max(...ys)-Math.min(...ys),ax=w>=h?0:1,lo=Math.min(...(ax?ys:xs)),hi=Math.max(...(ax?ys:xs)),tot=area(poly),f=sa/(sa+sb);
  let l=lo,u=hi;for(let k=0;k<40;k++){const m=(l+u)/2;if(area(clip(poly,ax,m,true))/tot<f)l=m;else u=m}
  const c=(l+u)/2;split(A,clip(poly,ax,c,true));split(B,clip(poly,ax,c,false))
 })(items,circ);
 return cells}
const polyPath=p=>'M'+p.map(q=>q[0].toFixed(1)+' '+q[1].toFixed(1)).join('L')+'Z';
