/* ===== v13: richer chart forms. Old charts stay in the DOM, hidden, so their code keeps running safely. ===== */
(function(){
const hide=ids=>ids.forEach(id=>{const e=document.getElementById(id);if(e)e.hidden=true});
const after=(id,html)=>{const e=document.getElementById(id);if(e)e.insertAdjacentHTML('afterend',html)};
const goIO=new IntersectionObserver(es=>es.forEach(e=>{if(e.isIntersecting){e.target.classList.add('go');goIO.unobserve(e.target)}}),{threshold:.25});
const watch=id=>{const e=document.getElementById(id);if(e)goIO.observe(e)};
watch('ptrv');
const R2=v=>Math.round(v*10)/10;
const HATCH=(id,col)=>`<pattern id="${id}" width="8" height="8" patternUnits="userSpaceOnUse" patternTransform="rotate(45)"><rect width="8" height="8" style="fill:var(--bg)"/><line x1="0" y1="0" x2="0" y2="8" style="stroke:${col}" stroke-width="3"/></pattern>`;

/* ---------- 01 · radial stage clock ---------- */
hide(['rings']);
after('rings',`<div class="viz anim" id="clock"></div><p class="cap">Each ring is one school stage. Its length is the share of children of the right age who are enrolled, 2025–26. The small mark on each ring is India's figure.</p>`);
mount('clock',w=>{const n=D.ner['2025–26'],S=Math.min(w,560),c=S/2,sm=S<420,band=Math.max(16,S*.055),gap=band*.45,R0=c-6,names=D.stages.map(s=>sm&&s.k==='h'?'Higher sec.':s.name);
 const pt=(r,a)=>{const t=(a-90)*Math.PI/180;return[c+r*Math.cos(t),c+r*Math.sin(t)]};
 const arc=(r,v)=>{const a=270*v/100,[x0,y0]=pt(r,0),[x1,y1]=pt(r,a);return `M${x0.toFixed(1)} ${y0.toFixed(1)}A${r} ${r} 0 ${a>180?1:0} 1 ${x1.toFixed(1)} ${y1.toFixed(1)}`};
 let s=`<svg viewBox="0 0 ${S} ${S}" width="${S}" height="${S}" style="max-width:100%;height:auto;display:block;margin:0 auto" role="img" aria-label="Right-age enrolment by stage, Nagaland 2025–26: ${names.map((m,i)=>m+' '+n.ng[i]).join(', ')}">`;
 n.ng.forEach((v,i)=>{const r=R0-band/2-i*(band+gap),hs=i===3,[tx,ty]=pt(r,270*n.ind[i]/100);
  s+=`<path d="${arc(r,100)}" fill="none" style="stroke:var(--mute)" stroke-width="${band}" stroke-linecap="round"/>`;
  s+=`<g ${tp(names[i],'Nagaland '+v+' in 100 children of the right age enrolled. India '+n.ind[i]+'.')} tabindex="0"><path class="draw" pathLength="100" style="--d:${i*160}ms;stroke:var(${hs?'--bad':'--good'})" d="${arc(r,v)}" fill="none" stroke-width="${band}" stroke-linecap="round"/>`;
  s+=`<circle cx="${tx.toFixed(1)}" cy="${ty.toFixed(1)}" r="${band*.22}" style="fill:var(--fg)"/></g>`;
  s+=`<text x="${(c-band/2-14).toFixed(1)}" y="${(c-r+band*.2).toFixed(1)}" text-anchor="end" style="font:800 ${sm?12:14}px var(--body);fill:var(--fg)">${names[i]}<tspan dx="8" style="font:400 ${sm?20:26}px var(--disp);fill:var(${hs?'--bad':'--fg'})">${v.toFixed(1)}</tspan></text>`});
 const rin=R0-band/2-3*(band+gap)-band/2-8,fs=Math.min(S*.1,rin*.5);
 s+=`<text x="${c}" y="${c+fs*.18}" text-anchor="middle" style="font:400 ${fs}px var(--disp);fill:var(--fg)">79.55<tspan style="font-size:.5em">%</tspan></text><text x="${c}" y="${c+fs*.18+22}" text-anchor="middle" style="font:700 12px var(--body);fill:var(--fg)">can read and write</text><text x="${c}" y="${c+fs*.18+38}" text-anchor="middle" style="font:700 12px var(--body);fill:var(--fg)">Census 2011</text>`;
 return s+'</svg><div class="clk-key"><span><i class="dot"></i>India</span><span><i class="bar"></i>Nagaland</span></div>'});
watch('clock');

/* ---------- 02 · Marimekko ---------- */
hide(['tab2','v2','cap2']);
after('v2',`<div class="mkleg" aria-hidden="true"><span><i class="a"></i>Right age and enrolled</span><span><i class="b"></i>Enrolled, but older or younger than the official age</span><span><i class="c"></i>Shortfall: fewer students than children of this age</span></div><div class="viz anim" id="mekko"></div><p class="cap" id="capm">Column width is the number of students in each stage, 2025–26. Heights are per 100 children of the official age and use 2024–25, the latest year with figures for students of all ages. Solid is right age, lighter is older or younger, and light red is the shortfall below 100. Some of each narrowing is students who are still in earlier classes, not only children who left. The three numbers in each column add up to 100.</p>`);
mount('mekko',w=>{const E=D.enrol['2025–26'],G=D.ger['2024–25'].ng,N=D.ner['2024–25'].ng,tot=E.reduce((a,b)=>a+b,0),H=Math.min(380,Math.max(260,w*.42)),T=34,B=w<520?88:54,gp=6,W=w-gp*3,names=D.stages.map(s=>s.name),sh=['Primary','Upper pri.','Second.','Higher sec.'],Y=v=>T+H*(1-v/100);
 let s=`<svg viewBox="0 0 ${w} ${T+H+B}" width="${w}" height="${T+H+B}" style="max-width:100%;height:auto" role="img" aria-label="Students by stage, 2024–25, with right-age, other-age and gap to 100 per stage"><defs>${HATCH('mkH','var(--bad)')}</defs>`;
 let x=0;E.forEach((e,i)=>{const cw=W*e/tot,narrow=cw<86,cx=x+cw/2,d=`style="--d:${i*120}ms"`;
  s+=`<g class="grow" ${d}><rect x="${x}" y="${T}" width="${cw}" height="${Y(G[i])-T}" style="fill:#F0A596" ${tp(names[i]+': shortfall',R2(100-G[i])+' per 100 of the official age is the shortfall: even counting students of every age, there are fewer students than children of this age (2024–25 rates).')} tabindex="0"/>`;
  s+=`<rect x="${x}" y="${Y(G[i])}" width="${cw}" height="${Y(N[i])-Y(G[i])}" style="fill:var(--good);opacity:.45" ${tp(names[i]+': other ages',R2(G[i]-N[i])+' per 100 are enrolled but older or younger than the official age.')} tabindex="0"/>`;
  s+=`<rect x="${x}" y="${Y(N[i])}" width="${cw}" height="${T+H-Y(N[i])}" style="fill:var(--good)" ${tp(names[i]+': right age',N[i]+' per 100 children of the official age are enrolled at this stage. '+nf(e)+' students in total.')} tabindex="0"/></g>`;
  const nn=Math.round(N[i]),gg=Math.round(100-G[i]),mm=100-nn-gg,fz=narrow?16:24,lab=(y,v,c)=>`<text x="${cx}" y="${y}" text-anchor="middle" style="font:400 ${fz}px var(--disp);fill:${c||'var(--fg)'};paint-order:stroke;stroke:var(--bg);stroke-width:${c?0:5}px;pointer-events:none">${v}</text>`;
  s+=`<text x="${cx}" y="${Y(N[i])+(narrow?22:34)}" text-anchor="middle" style="font:400 ${narrow?18:30}px var(--disp);fill:var(--bg);pointer-events:none">${nn}</text>`;
  const hm=Y(N[i])-Y(G[i]),hg=Y(G[i])-T;
  s+=lab(Y(G[i])+hm/2+fz*.35,mm);
  s+=lab(T+Math.max(hg/2,fz*.55)+fz*.35,gg,hg>=fz+10?'#6B1A10':null);
  const lo=(narrow&&i===3)?34:0;s+=`<text x="${lo?w:cx}" y="${T+H+20+lo}" text-anchor="${lo?'end':'middle'}" style="font:800 ${narrow?11:13}px var(--body);letter-spacing:.06em;text-transform:uppercase;fill:var(--fg)">${narrow?sh[i]:names[i]}</text><text x="${lo?w:cx}" y="${T+H+38+lo}" text-anchor="${lo?'end':'middle'}" style="font:600 12px var(--body);fill:var(--fg);opacity:.8">${nf(e)}</text>`;
  x+=cw+gp});
 s+=`<text x="0" y="16" style="font:700 12px var(--body);fill:var(--fg)">100 children of the official age ↓</text>`;
 return s+'</svg>'});
watch('mekko');

/* ---------- 03 · bivariate map + beeswarm ---------- */
hide(['pills3','v3','panel3','cap3','pills3b','v3b','cap3b']);
const MP={m:'ner',sc:['#E4EEDD','#A9CDA2','#4E9A6E','#1D5A41']};
const mpVals=()=>D.dist.map(d=>MP.m==='ner'?d.ner[3]:d.lit);
const mpTip=d=>{const ner=MP.m==='ner',key=x=>ner?x.ner[3]:x.lit,rk=D.dist.slice().sort((a,b)=>key(b)-key(a)).findIndex(x=>x.name===d.name)+1,r0=Math.round;
 return (ner?'Literacy '+d.lit+'% (2011). ':'Higher-secondary enrolment '+d.ner[3]+'% (2024–25). ')+'Rank '+rk+' of '+D.dist.length+(ner?' for enrolment':' for literacy')+'. Enrolment from primary to higher secondary: '+[0,1,2,3].map(k=>(d.ner[k]>100?'100+':r0(d.ner[k]))).join(', ')+'. Government schools: '+d.gov[0]+' primary, '+d.gov[3]+' higher secondary.'};
const mpBin=v=>{const s=mpVals().slice().sort((a,b)=>a-b);const i=s.indexOf(v);return Math.min(3,Math.floor(i*4/s.length))};
(document.querySelector('#s3 .dist')||$('#panel3')).insertAdjacentHTML('afterend',`<div class="mp3"><div class="pills" id="mppills" role="group" aria-label="Map measure"><button type="button" aria-pressed="true" data-m="ner">Higher-secondary enrolment</button><button type="button" aria-pressed="false" data-m="lit">Literacy (2011)</button></div><p class="mp-say" id="mpsay" aria-live="polite"></p><div class="mp-body"><div class="viz anim" id="bvmap"></div><div class="mp-key" id="mpkey"></div></div></div>`);
const mpSay=()=>{const r=D.dist.map(d=>[d.name,MP.m==='ner'?d.ner[3]:d.lit]).sort((a,b)=>b[1]-a[1]),hi=r[0],lo=r[r.length-1];
 $('#mpsay').innerHTML=MP.m==='ner'?`<b>${hi[0]}</b> leads at higher secondary with ${hi[1]}% enrolled. <b>${lo[0]}</b> is lowest at ${lo[1]}%.`:`<b>${hi[0]}</b> is the most literate district at ${hi[1]}%. <b>${lo[0]}</b> is lowest at ${lo[1]}% (Census 2011).`;
 const v=mpVals(),mn=Math.min(...v),mx=Math.max(...v);
 $('#mpkey').innerHTML=`<div class="mp-bar">${MP.sc.map(c=>`<i style="background:${c}"></i>`).join('')}</div><div class="mp-ends"><span>${MP.m==='ner'?'Fewer':'Lower'} · ${mn.toFixed(1)}%</span><span>${MP.m==='ner'?'More':'Higher'} · ${mx.toFixed(1)}%</span></div><p>${MP.m==='ner'?'Darker green means more children of the right age are enrolled at higher secondary (2024–25).':'Darker green means a larger share of people who can read and write (Census 2011).'}</p><p class="note">Hover a district for its rank, enrolment by stage and school counts.</p>`};
mount('bvmap',w=>{const sz=Math.min(w,560);
 let s=`<svg viewBox="0 0 ${NGM.W} ${NGM.H}" width="${sz}" height="${sz*NGM.H/NGM.W}" style="max-width:100%;height:auto;display:block" role="img" aria-label="Map of Nagaland's districts shaded by ${MP.m==='ner'?'higher-secondary enrolment':'literacy'}">`;
 D.dist.forEach((d,i)=>{const p=NGM.p[d.name];if(!p)return;const v=MP.m==='ner'?d.ner[3]:d.lit,b=mpBin(v);
  s+=`<path class="bvp" d="${p}" style="fill:${MP.sc[b]};--d:${i*60}ms" stroke="#F5EBD8" stroke-width="2.5" stroke-linejoin="round" ${tp(d.name,mpTip(d))} tabindex="0"/>`});
 D.dist.forEach(d=>{const c=NGM.c[d.name];if(!c)return;const v=MP.m==='ner'?d.ner[3]:d.lit,dark=mpBin(v)>=2,col=dark?'#F5EBD8':'#16110F',fs=w<480?16:14;
  s+=`<text x="${c[0]}" y="${c[1]-4}" text-anchor="middle" style="font:800 ${fs}px var(--body);fill:${col};pointer-events:none">${d.name}</text><text x="${c[0]}" y="${c[1]+fs+3}" text-anchor="middle" style="font:400 ${fs+6}px var(--disp);fill:${col};pointer-events:none">${v.toFixed(1)}</text>`});
 return s+'</svg>'});
mpSay();
$$('#mppills button').forEach(b=>b.addEventListener('click',()=>{MP.m=b.dataset.m;$$('#mppills button').forEach(x=>x.setAttribute('aria-pressed',x===b));mpSay();draw(REG['bvmap'])}));
watch('bvmap');
// beeswarm
const h3b=[...document.querySelectorAll('#s3 .mini-h')].find(e=>/Eleven districts on the map/.test(e.textContent));
if(h3b){h3b.innerHTML='Every district, stage by stage <small class="vint">net enrolment · 2024–25</small>';const cp=h3b.nextElementSibling;if(cp&&cp.classList.contains('cap'))cp.textContent='Each dot is a district. Further right means more children of the right age enrolled. Watch the dots slide left as the stages rise, while Dimapur and Kohima stay ahead.'}
after('v3b',`<div class="swleg" aria-hidden="true"><span><i class="g"></i>Dimapur and Kohima</span><span><i class="m"></i>The other nine districts</span></div><div class="viz anim" id="swarm" style="margin-top:8px"></div>`);
mount('swarm',w=>{const L=w<520?92:150,Rr=26,rmin=w<520?64:76,T=26,r=w<520?7:9,X=v=>L+(w-L-Rr)*Math.min(v,140)/140,names=D.stages.map(s=>s.name);
  const rows=names.map((nm,k)=>{const pts=D.dist.map(d=>({d,x:X(d.ner[k])})).sort((a,b)=>a.x-b.x),placed=[];let reach=0;
   pts.forEach(p=>{let off=0,step=0;for(;;){if(!placed.some(q=>Math.hypot(q.x-p.x,q.off-off)<r*2+1.5)){p.off=off;break}step++;off=(step%2?1:-1)*Math.ceil(step/2)*(r*2+1.5)*.6}placed.push(p);reach=Math.max(reach,Math.abs(off))});
   return {nm,k,pts,rh:Math.max(rmin,reach*2+r*2+34)}});
  let y0=T;rows.forEach(R=>{R.cy=y0+R.rh/2;y0+=R.rh});
  const H=y0+34,yb=y0;
  let s=`<svg viewBox="0 0 ${w} ${H}" width="${w}" height="${H}" style="max-width:100%;height:auto" role="img" aria-label="Net enrolment of each district at each stage, 2024–25">`;
  [0,50,100].forEach(v=>s+=`<line x1="${X(v)}" x2="${X(v)}" y1="${T-6}" y2="${yb}" style="stroke:var(--soft)" stroke-width="2" stroke-dasharray="${v===100?'0':'4 5'}"/><text x="${X(v)}" y="${H-8}" text-anchor="middle" style="font:700 12px var(--body);fill:var(--fg)">${v}%</text>`);
  rows.forEach((R,ri)=>{const {nm,k,cy}=R;
   if(ri>0)s+=`<line x1="0" x2="${w}" y1="${cy-R.rh/2}" y2="${cy-R.rh/2}" style="stroke:var(--soft)" stroke-width="1" stroke-dasharray="1 5"/>`;
   s+=`<text x="0" y="${cy+5}" style="font:800 ${w<520?11:13}px var(--body);letter-spacing:.06em;text-transform:uppercase;fill:var(--fg)">${w<520?['Primary','Upper pri.','Secondary','Higher sec.'][k]:nm}</text><line x1="${L}" x2="${w-Rr}" y1="${cy}" y2="${cy}" style="stroke:var(--soft)" stroke-width="1.5"/>`;
   R.pts.forEach(p=>{const py=cy+p.off,top=p.d.name==='Dimapur'||p.d.name==='Kohima';
    s+=`<circle class="sw" cx="${p.x.toFixed(1)}" cy="${py.toFixed(1)}" r="${r}" style="fill:var(${top?'--good':'--fg'});opacity:${top?1:.55};--d:${k*140}ms;--sx:${(L-p.x).toFixed(0)}px" stroke="var(--bg)" stroke-width="1.5" ${tp(p.d.name+', '+nm,p.d.ner[k]+'% net enrolment, 2024–25.'+(p.d.ner[k]>100?' Above 100% can include students from other districts.':''))} tabindex="0"/>`;
    if(top&&(k===3||k===0))s+=`<text x="${Math.min(p.x,w-24).toFixed(1)}" y="${(w<520&&k===3&&p.d.name==='Kohima'?py+r+16:py-r-6).toFixed(1)}" text-anchor="middle" style="font:800 12px var(--body);fill:var(--good)">${p.d.name}</text>`})});
 return s+'</svg>'});
watch('swarm');

/* ---------- 04 · Sankey leaky pipeline ---------- */
hide(['yr4','cmp4','v4']);
after('v4',`<div class="skleg" aria-hidden="true"><span><i style="background:var(--good)"></i>Continued to the next stage</span><span><i style="background:var(--bad)"></i>Did not continue at this step</span></div><div class="viz anim" id="sankey" style="margin-top:14px"></div><p class="cap">The band starts as 100 students who finish primary school. At each step, the part that peels away in red does not enter the next stage. This combines the three 2025–26 rates as if one group of students passed through all of them, so it is an illustration, not a tracked cohort, and dropout within a stage is not included.</p>`);
mount('sankey',w=>{const t=D.tr['2025–26'].Nagaland,ph=w<560,sc=(ph?120:190)/100,T=58,nodes=[100],labs=w<560?['Class 5','Class 6','Class 9','Class 11']:['Finish Class 5','Enter Class 6','Enter Class 9','Enter Class 11'];
 t.forEach(r=>nodes.push(nodes[nodes.length-1]*r/100));
 const L=ph?10:24,Rr=ph?54:90,xs=nodes.map((_,i)=>L+(w-L-Rr)*i/3),yB=T+100*sc+(ph?90:120),H=yB+40;
 let s=`<svg viewBox="0 0 ${w} ${H}" width="${w}" height="${H}" style="max-width:100%;height:auto;overflow:visible" role="img" aria-label="Illustrative flow of 100 students: ${nodes.map(v=>v.toFixed(1)).join(', ')} remain after each step">`;
 for(let i=0;i<3;i++){const x0=xs[i],x1=xs[i+1],h0=nodes[i]*sc,h1=nodes[i+1]*sc,lk=nodes[i]-nodes[i+1],a=T+h1,b=T+h0,xe=x0+(x1-x0)*.42,Lw=b-a,ym=yB-10,big=i===2;
  s+=`<g class="flow" style="--d:${i*380}ms"><path d="M${x0} ${T}H${x1}V${T+h1}H${x0}Z" style="fill:var(--good)" opacity=".9"/>`;
  s+=`<path d="M${x0} ${a}C${x0+(xe-x0)*.9} ${a} ${xe+Lw} ${a+(ym-a)*.3} ${xe+Lw} ${yB}H${xe}C${xe} ${b+(ym-b)*.35} ${x0+(xe-x0)*.6} ${b} ${x0} ${b}Z" style="fill:var(--bad)" opacity="${big?1:.75}" ${tp(t.length&&D.trSteps[i][0]+' did not continue',(100-t[i]).toFixed(1)+' in 100 at this step did not enter the next stage in 2025–26. In this illustration that is '+lk.toFixed(1)+' of the original 100.')} tabindex="0"/>`;
  s+=`<text x="${xe+Lw/2}" y="${yB+(big?34:26)}" text-anchor="middle" style="font:400 ${big?34:24}px var(--disp);fill:var(--bad)">${lk.toFixed(1)}</text></g>`}
 nodes.forEach((v,i)=>{const x=xs[i],h=v*sc;
  s+=`<rect x="${x-4}" y="${T}" width="8" height="${h}" style="fill:var(--fg)"/>`;
  s+=`<text x="${i===3?x+10:x+8}" y="${T+h/2+12}" style="font:400 ${ph?24:38}px var(--disp);fill:var(--bg);${i===3?'fill:var(--fg)':''}" ${i===3?'':'class="lbl-in"'}>${i===0?'100':v.toFixed(1)}</text>`;
  s+=`<text x="${x}" y="${T-16}" text-anchor="${i===0?'start':i===3?'end':'middle'}" style="font:800 ${ph?11:13}px var(--body);letter-spacing:.06em;text-transform:uppercase;fill:var(--fg)">${labs[i]}</text>`});
 return s+'</svg>'});
watch('sankey');

/* pass-rate dumbbell */
hide(['h4a','v4a','yr4a','yl4a']);
document.getElementById('stp1').querySelector('.stp-q').insertAdjacentHTML('afterend','<div class="viz anim" id="dumb"></div>');
mount('dumb',w=>{const h=D.hslc,L=46,Rr=52,rh=40,T=30,X=v=>L+(w-L-Rr)*(v-20)/80,H=T+rh*h.years.length+28;
 let s=`<svg viewBox="0 0 ${w} ${H}" width="${w}" height="${H}" style="max-width:100%;height:auto" role="img" aria-label="Class 10 pass rates by year, government and private schools">`;
 s+=`<circle cx="${L}" cy="10" r="6" style="fill:var(--bad)"/><text x="${L+12}" y="14" style="font:700 12px var(--body);fill:var(--fg)">Government</text><circle cx="${L+110}" cy="10" r="6" style="fill:var(--good)"/><text x="${L+122}" y="14" style="font:700 12px var(--body);fill:var(--fg)">Private</text>`;
 h.years.forEach((y,i)=>{const cy=T+rh*i+rh/2,g=h.gov[i],p=h.priv[i];
  s+=`<g ${tp('Class 10, '+y,'Government '+g+'%, private '+p+'%. A gap of '+(p-g).toFixed(1)+' points.')} tabindex="0"><text x="0" y="${cy+5}" style="font:800 13px var(--body);fill:var(--fg)">${y}</text><line class="db" x1="${X(g)}" x2="${X(p)}" y1="${cy}" y2="${cy}" style="stroke:var(--soft);--d:${i*90}ms" stroke-width="6" stroke-linecap="round"/><circle cx="${X(g)}" cy="${cy}" r="8" style="fill:var(--bad)"/><circle cx="${X(p)}" cy="${cy}" r="8" style="fill:var(--good)"/><text x="${w-2}" y="${cy+6}" text-anchor="end" style="font:400 20px var(--disp);fill:var(--fg)">+${Math.round(p-g)}</text></g>`});
 [20,60,100].forEach(v=>s+=`<text x="${X(v)}" y="${H-4}" text-anchor="middle" style="font:700 12px var(--body);fill:var(--fg);opacity:.75">${v}%</text>`);
 return s+'</svg>'});
watch('dumb');

/* PARAKH as 100-school rows */
hide(['v4d']);
after('v4d',`<div class="viz" id="schools100"></div>`);
$('#schools100').innerHTML=D.parakh.map(r=>{let sq='';for(let k=0;k<100;k++)sq+=`<i class="${k<r[1]?'on':''}"></i>`;return `<div class="s100" ${tp(r[0],r[1]+' in 100 reporting schools said so.')} tabindex="0"><p><b>${r[1]}</b> in 100 schools: ${r[0].charAt(0).toLowerCase()+r[0].slice(1)}</p><div class="grid100">${sq}</div></div>`}).join('')+`<p class="cap" style="margin-top:8px">Each square is 1 in 100 reporting schools. A filled square is a school where more than half of students did this right after Class 10.</p>`;

/* ---------- 05 · icicle of government schools ---------- */
hide(['v5c']);
after('v5c',`<div class="viz anim" id="icicle"></div>`);
mount('icicle',w=>{const NM=['Primary','Middle','High','Higher secondary'],tot=[0,1,2,3].map(k=>D.dist.reduce((a,d)=>a+d.gov[k],0)),mx=tot[0],rh=w<520?64:76,L=0,T=6,H=T+rh*4+8,ord=D.dist.slice().sort((a,b)=>b.gov[0]-a.gov[0]);
 let s=`<svg viewBox="0 0 ${w} ${H}" width="${w}" height="${H}" style="max-width:100%;height:auto" role="img" aria-label="Government schools by category and district, 2023–24">`;
 tot.forEach((t,k)=>{const W=(w-L)*t/mx,x0=L+(w-L-W)/2,y=T+rh*k;let x=x0;
  ord.forEach((d,j)=>{const sw=W*d.gov[k]/t;s+=`<rect class="ic" x="${x.toFixed(1)}" y="${y+22}" width="${Math.max(0,sw-1.5).toFixed(1)}" height="${rh-30}" style="fill:var(${k===3?'--bad':'--fg'});opacity:${(1-j*.055).toFixed(2)};--d:${k*120}ms" ${tp(d.name+', '+NM[k],d.gov[k]+' government '+NM[k].toLowerCase()+' schools, 2023–24.')} tabindex="0"/>`;x+=sw});
  s+=`<text x="${x0}" y="${y+14}" style="font:800 ${w<520?12:14}px var(--body);letter-spacing:.04em;fill:var(--fg);pointer-events:none">${NM[k]} · ${nf(t)}</text>`});
 return s+'</svg>'});
after('icicle',`<p class="cap" style="margin-top:10px">Each row is a school category, and each block within it is a district. Hover a block to see the district.</p>`);
watch('icicle');

/* ---------- 06 · proportional map, butterfly, paired waffle ---------- */
hide(['tab6','v6','cap6']);const s6d=$('#src6');if(s6d)s6d.closest('details').hidden=true;
after('v6',`<div class="pm"><div class="viz anim" id="pmap"></div><div class="pmkey"><p><i class="dot"></i>Filled circle: undergraduates studying in the district, 2023–24.</p><p><i class="ring"></i>Outer ring: moves from villages to towns for education, 2011.</p><p class="note">College location is not where students live. The records do not show moves out of the state.</p></div></div><details class="src"><summary>Details and source</summary><p>Nagaland Statistical Handbook 2025, table 20.3: undergraduates by institution district, 2023–24, 38,744 students. Census of India 2011, migration table D-03: rural-to-urban moves within Nagaland for education, by destination district. Newer districts are shown within their 2011 parent districts.</p></details>`);
mount('pmap',w=>{const ug={},mv={};D.ug.forEach(r=>ug[r[0]]=r[1]);D.mv.forEach(r=>mv[r[0]]=r[1]);ug.Dimapur+=(ug['Chümoukedima']||0)+(ug['Niuland']||0);
 const mxA=Math.max(...Object.values(ug)),k=46/Math.sqrt(mxA),sz=Math.min(w,600);
 let s=`<svg viewBox="0 0 ${NGM.W} ${NGM.H}" width="${sz}" height="${sz*NGM.H/NGM.W}" style="max-width:100%;height:auto;display:block;overflow:visible" role="img" aria-label="Map of where undergraduates study and where education moves went">`;
 D.dist.forEach(d=>{const p=NGM.p[d.name];if(p)s+=`<path d="${p}" style="fill:var(--mute)" stroke="var(--bg)" stroke-width="2.5"/>`});
 Object.keys(NGM.c).sort((a,b)=>(ug[b]||0)-(ug[a]||0)).forEach((n,i)=>{const [cx,cy]=NGM.c[n],ru=k*Math.sqrt(ug[n]||0),rm=k*Math.sqrt(mv[n]||0);
  s+=`<g class="pop" style="--d:${i*70}ms;transform-origin:${cx}px ${cy}px" ${tp(n,nf(ug[n]||0)+' undergraduates study here (2023–24). '+nf(mv[n]||0)+' moves into its towns for education (2011).')} tabindex="0"><circle cx="${cx}" cy="${cy}" r="${Math.max(rm,4)}" fill="none" style="stroke:var(--fg)" stroke-width="2.5" stroke-dasharray="5 4"/><circle cx="${cx}" cy="${cy}" r="${Math.max(ru,4)}" style="fill:var(--bad)" opacity=".85"/></g>`;
  if(ru>22)s+=`<text x="${cx}" y="${cy+8}" text-anchor="middle" style="font:400 ${w<480?30:24}px var(--disp);fill:#F5EBD8;pointer-events:none">${nf(ug[n])}</text>`;
  s+=`<text x="${cx}" y="${cy+Math.max(ru,rm,4)+(w<480?24:18)}" text-anchor="middle" style="font:800 ${w<480?19:14}px var(--body);fill:var(--fg);pointer-events:none">${n}</text>`});
 return s+'</svg>'});
watch('pmap');

hide(['v6d']);
after('v6d',`<div class="viz anim" id="bfly"></div>`);
mount('bfly',w=>{const h=D.he,c=w/2,row=(lbl,v,dir,y,col)=>{let g='';const cols=w<520?10:20,cell=Math.min(14,(c-30)/cols),n=Math.round(v);for(let k=0;k<100;k++){const cx=dir<0?c-18-(k%cols)*cell-cell/2:c+18+(k%cols)*cell+cell/2,cy=y+Math.floor(k/cols)*cell;g+=`<circle cx="${cx.toFixed(1)}" cy="${cy.toFixed(1)}" r="${(cell*.38).toFixed(1)}" style="fill:var(${k<n?col:'--mute'})"/>`}return g},
  rows=Math.ceil(100/(w<520?10:20)),cell=Math.min(14,(c-30)/(w<520?10:20)),H=48+rows*cell+20;
 let s=`<svg viewBox="0 0 ${w} ${H}" width="${w}" height="${H}" style="max-width:100%;height:auto" role="img" aria-label="Higher education enrolment per 100 aged 18 to 23: women ${h.f}, men ${h.m}">`;
 s+=`<g ${tp('Women',h.f+' in 100 women aged 18–23 are in higher education.')} tabindex="0"><text x="${c-18}" y="30" text-anchor="end" style="font:400 30px var(--disp);fill:var(--good)">${h.f} <tspan style="font:800 13px var(--body);fill:var(--fg)">WOMEN</tspan></text>${row('W',h.f,-1,52,'--good')}</g>`;
 s+=`<g ${tp('Men',h.m+' in 100 men aged 18–23 are in higher education.')} tabindex="0"><text x="${c+18}" y="30" style="font:800 13px var(--body);fill:var(--fg)">MEN <tspan style="font:400 30px var(--disp);fill:var(--fg)">${h.m}</tspan></text>${row('M',h.m,1,52,'--fg')}</g>`;
 s+=`<line x1="${c}" x2="${c}" y1="8" y2="${H-6}" style="stroke:var(--soft)" stroke-width="2"/>`;
 return s+'</svg>'});
watch('bfly');

hide(['v6a','v6b']);
(function(){const w=$('#wplan');if(!w)return;const P=D.plan,n=P.reduce((a,b)=>a+b[1],0);
 const g=[['Higher education',P[0][1],'var(--good)'],['Work: a job or other jobs',P[1][1]+P[3][1],'#16110F'],['Apprenticeship or internship',P[2][1],'#C9822B'],['Gap year or vocational training',P[4][1]+P[5][1],'#A99F90']];
 const c=alloc(g.map(x=>x[1]),100);let h='',k=0;
 g.forEach((s,si)=>{for(let j=0;j<c[si];j++,k++)h+=`<i class="on" data-tip="${esc(s[0]+'|'+c[si]+' in 100 of the '+nf(n)+' answers.')}" style="background:${s[2]};--d:${k*8}ms"></i>`});
 w.innerHTML=h;w.setAttribute('role','img');w.setAttribute('aria-label',g.map((s,si)=>c[si]+' in 100 '+s[0]).join(', '));
 $('#wplanleg').innerHTML=`<ul class="legend plegend">${g.map((s,si)=>`<li><span><i style="background:${s[2]}"></i><b>${c[si]}</b> ${s[0]}</span></li>`).join('')}</ul>`;
 goIO.observe(w)})();

/* ---------- 07 · re-exam clusters + waterfall ---------- */
hide(['v7','v7b']);
after('v7',`<div class="viz anim" id="clus"></div>`);
mount('clus',w=>{const R=D.reex,ph=w<560,cw=w/3,sp0=(ph?3.3:4.6)*2.25,sp=Math.min(sp0,(cw/2-10)/(.62*Math.sqrt(640)+.45)),dr=sp/2.25,maxR=sp*.62*Math.sqrt(640)+dr,cy=maxR+6,H=cy+maxR+66;
 let s=`<svg viewBox="0 0 ${w} ${H}" width="${w}" height="${H}" style="max-width:100%;height:auto" role="img" aria-label="Class 12 re-examination 2023 by stream: ${R.map(r=>r[0]+' '+r[2]+' of '+r[1]+' passed').join(', ')}">`;
 R.forEach((r,j)=>{const cx=cw*j+cw/2,[n,p]=[r[1],r[2]];let g='';
  for(let i=0;i<n;i++){const rr=sp*.62*Math.sqrt(i+.5),th=i*2.39996,x=cx+rr*Math.cos(th),y=cy+rr*Math.sin(th),ok=i<p;
   g+=`<circle cx="${x.toFixed(1)}" cy="${y.toFixed(1)}" r="${dr}" style="fill:var(${ok?'--fg':'--bad'});--sx:${(w/2-cx).toFixed(0)}px;--d:${Math.round(i*.9)}ms" class="cd"/>`}
  s+=`<g ${tp(r[0],p+' of '+n+' candidates passed ('+Math.round(p/n*100)+'%).')} tabindex="0">${g}</g>`;
  s+=`<text x="${cx}" y="${H-46}" text-anchor="middle" style="font:800 ${ph?12:14}px var(--body);letter-spacing:.08em;text-transform:uppercase;fill:var(--fg)">${r[0]}</text><text x="${cx}" y="${H-10}" text-anchor="middle" style="font:400 ${ph?20:26}px var(--disp);fill:var(--fg)">${p} of ${n}</text>`});
 return s+'</svg>'});
after('clus',`<p class="cap" style="margin-top:6px">One dot is one candidate. Cream dots in the centre passed; dark dots around them did not.</p>`);
watch('clus');

after('v7b',`<div class="viz anim" id="wfall"></div>`);
mount('wfall',w=>{const [a,b,c]=D.oos,H=280,T=30,B=58,Y=v=>T+(H-T-B)*(1-v/a),cw=Math.min(120,w/6),gx=(w-cw*5)/4;
 const col=[{v:a,y0:0,t:'Identified, 2019–20',k:'fg'},{v:a-b,y0:b,t:'Not trained',k:'drop'},{v:b,y0:0,t:'Received training',k:'fg'},{v:b-c,y0:c,t:'Not mainstreamed',k:'drop'},{v:c,y0:0,t:'Mainstreamed, 2020–21',k:'hi'}];
 let s=`<svg viewBox="0 0 ${w} ${H}" width="${w}" height="${H}" style="max-width:100%;height:auto" role="img" aria-label="Out-of-school children: ${a} identified, ${b} trained, ${c} mainstreamed"><defs>${HATCH('wfH','var(--fg)')}</defs>`;
 col.forEach((o,i)=>{const x=i*(cw+gx),top=Y(o.y0+o.v),bot=Y(o.y0),dr=o.k==='drop';
  s+=`<g class="wf" style="--d:${i*150}ms" ${tp(o.t,(dr?'−':'')+o.v+' children.'+(i===3?' Their later status is not stated.':''))} tabindex="0"><rect x="${x}" y="${top}" width="${cw}" height="${Math.max(2,bot-top)}" ${dr?'fill="url(#wfH)"':`style="fill:var(${o.k==='hi'?'--hi':'--fg'})"`} stroke="${dr?'var(--fg)':'none'}" stroke-width="2"/>`;
  s+=`<text x="${x+cw/2}" y="${top-8}" text-anchor="middle" style="font:400 ${w<520?18:24}px var(--disp);fill:var(--fg)">${dr?'−':''}${o.v}</text></g>`;
  s+=`<text x="${x+cw/2}" y="${H-B+20}" text-anchor="middle" style="font:700 ${w<520?10.5:12}px var(--body);fill:var(--fg)">${o.t.split(', ')[0]}</text>${o.t.includes(', ')?`<text x="${x+cw/2}" y="${H-B+36}" text-anchor="middle" style="font:600 ${w<520?10.5:12}px var(--body);fill:var(--fg);opacity:.85">${o.t.split(', ')[1]}</text>`:''}`;
  if(i<4)s+=`<line x1="${x+cw}" x2="${x+cw+gx}" y1="${Y(i%2?col[i].y0:o.v)}" y2="${Y(i%2?col[i].y0:o.v)}" style="stroke:var(--fg)" stroke-width="1.5" stroke-dasharray="3 3"/>`});
 return s+'</svg>'});
watch('wfall');

/* ---------- 08 · simplified: narrow / can't see / who helps ---------- */
hide(['v8']);
after('v8',`<div id="s8x"></div>`);
(function(){const n=D.ner['2025–26'].ng,st=['Primary','Upper primary','Secondary','Higher secondary'];
 let b='';st.forEach((nm,i)=>{if(i){const d=Math.round(n[i-1]-n[i]);b+=`<div class="s8d"><span>${d} fewer</span></div>`}
  b+=`<div class="s8r"><span class="nm">${nm}</span><div class="tr"><i style="width:${n[i]}%"></i></div><b>${f1(n[i])}</b></div>`});
 const gaps=[['Where leavers go','after Class 10 and 12'],['Who goes on after Class 12','as a record of individual students'],['Why students leave','only state-wide figures exist']];
 const nx=[['1','Funders','Follow a group of students after Class 10 and 12.'],['2','Government','Publish the “too far” distance rule. Split figures by district.'],['3','Researchers','Test whether distance and money explain the drop.']];
 $('#s8x').innerHTML=`<div class="s8b"><h3 class="s8h"><i>A</i> Where it narrows</h3><p class="s8s">Children of the right age who are enrolled, per 100 (2025–26)</p><div class="s8bars anim" id="s8bars">${b}</div></div>
 <div class="s8b"><h3 class="s8h"><i>B</i> What the records cannot show</h3><div class="s8gaps">${gaps.map(g=>`<div><b>${g[0]}</b><span>${g[1]}</span></div>`).join('')}</div></div>
 <div class="s8b"><h3 class="s8h"><i>C</i> Who can fill the gaps</h3><div class="s8who">${nx.map(x=>`<div><em>${x[0]}</em><b>${x[1]}</b><p>${x[2]}</p></div>`).join('')}</div></div>`;
 $('#v8b').hidden=true;watch('s8bars')})();
})();

/* v25: step-by-step evidence */
(function(){const P=['stp1','stp2','stp3'],NX=['Next: after Class 10','Next: dropout',''];let k=0;
 const show=i=>{k=i;P.forEach((id,n)=>document.getElementById(id).hidden=n!==i);
  $('#stpCount').textContent='Step '+(i+1)+' of 3';document.querySelectorAll('.stp-dots i').forEach((d,n)=>d.classList.toggle('on',n===i));
  $('#stpBack').disabled=i===0;const nx=$('#stpNext');nx.hidden=i===2;nx.textContent=NX[i];
  setTimeout(()=>window.dispatchEvent(new Event('resize')),30)};
 $('#stpNext').onclick=()=>show(Math.min(2,k+1));$('#stpBack').onclick=()=>show(Math.max(0,k-1));
 const ob=new MutationObserver(()=>{});})();

/* v28: audit fixes */
(function(){document.querySelectorAll('.nir').forEach(n=>n.remove());
 const sd=document.querySelector('#s3 .src p');if(sd)sd.textContent+=' The map shows 11 districts on 2011 boundaries. Nagaland now has more districts; newer ones, such as Chümoukedima and Niuland, are counted within their parent districts here.';
 const pc=document.getElementById('pmap');if(pc)pc.insertAdjacentHTML('afterend','<p class="cap" style="font-size:.95rem;margin-top:8px">Dimapur here includes Chümoukedima and Niuland (2011 boundaries). The 83% in the headline counts Dimapur district alone.</p>')})();
