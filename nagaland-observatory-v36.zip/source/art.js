/* flat landscape generators */
function ridge(W,H,base,amp,seed,step=14){let d=`M0 ${H}L0 ${base}`;const ys=[];for(let x=0;x<=W;x+=step){const y=base+amp*(Math.sin(x*.0042+seed)*.55+Math.sin(x*.0105+seed*2.1)*.28+Math.sin(x*.026+seed*3.7)*.17);ys.push([x,y]);d+=`L${x} ${y.toFixed(1)}`}return{d:d+`L${W} ${H}Z`,ys}}
(function(){
 const W=1440,H=400;let s='';
 const l1=ridge(W,H,110,60,1.3),l2=ridge(W,H,200,55,4.1),l3=ridge(W,H,285,40,7.2);
 s+=`<path d="${l1.d}" fill="#A8112A"/><path d="${l2.d}" fill="#850D1E"/>`;
 // morung houses on mid ridge
 [180,430,690,1010,1260].forEach((x,i)=>{const p=l2.ys.find(q=>q[0]>=x)||l2.ys[10];s+=`<use href="#h" x="${x}" y="${p[1]-26}" width="${30+i%2*8}" height="${30+i%2*8}" fill="#16110F" opacity=".85"/>`});
 s+=`<path d="${l3.d}" fill="#16110F"/>`;
 l3.ys.forEach((p,i)=>{if(i%3===0){const h=26+((i*37)%24);s+=`<use href="#pine" x="${p[0]-7}" y="${p[1]-h+4}" width="${h*.5}" height="${h}" fill="#16110F"/>`}});
 $('#heroHills').innerHTML=s;
 const g=ridge(1440,300,90,60,2.2),g2=ridge(1440,300,170,50,5.5);
 $('#s2hills').innerHTML=`<path d="${g.d}" fill="#174D38"/><path d="${g2.d}" fill="#123D2C"/>`;
 $$('.band').forEach(b=>b.innerHTML='<rect width="100%" height="30" fill="url(#shawl)"/>');
})();
